"use strict";
exports.id = 940;
exports.ids = [940];
exports.modules = {

/***/ 4740:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5893);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(1853);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(1664);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_link__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _components_Banner_CommonBanner__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(7380);
/* harmony import */ var react_paginate__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(9700);
/* harmony import */ var react_paginate__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(react_paginate__WEBPACK_IMPORTED_MODULE_4__);



//components

//react paginate

const AllNews = ({ activePage =1 , totalPages , totalPosts  })=>{
    const router = (0,next_router__WEBPACK_IMPORTED_MODULE_1__.useRouter)();
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
        className: "",
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_Banner_CommonBanner__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z, {
                headerName: "News",
                imageLink: "/images/Banners/news.jpg"
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: "",
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: "layout component-padding",
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                            className: "flex flex-col gap-10",
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                className: "grid lg:grid-cols-4 gap-10",
                                children: totalPosts?.length > 0 && totalPosts?.map((data, index)=>{
                                    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((next_link__WEBPACK_IMPORTED_MODULE_2___default()), {
                                        href: `/news/${data.slug}`,
                                        className: "flex flex-col gap-5",
                                        children: [
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                className: "overflow-hidden rounded-[8px]",
                                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("img", {
                                                    src: data?.image_link,
                                                    alt: "",
                                                    className: "lg:h-[200px] rounded-[8px] object-cover hover:scale-110 transition-all duration-700"
                                                })
                                            }),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                className: "text-[20px] font-semibold line-clamp-2 text-color",
                                                children: data?.title
                                            })
                                        ]
                                    }, index);
                                })
                            })
                        })
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: "m-8",
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((react_paginate__WEBPACK_IMPORTED_MODULE_4___default()), {
                            className: "pagination flex gap-2 items-center justify-end mt-12",
                            breakLabel: "...",
                            nextLabel: "Next \uD83E\uDC16",
                            onPageChange: ({ selected  })=>{
                                console.log("Active Page", activePage);
                                console.log("Selected Page", selected + 1);
                                console.log("If active page and selected page are same then it is first page");
                                if (activePage !== selected + 1) {
                                    router.push(`/news/page/${selected + 1}`);
                                }
                            },
                            pageRangeDisplayed: 5,
                            initialPage: activePage - 1,
                            pageCount: totalPages,
                            previousLabel: "\uD83E\uDC14 Previous",
                            renderOnZeroPageCount: null,
                            activeClassName: "bg-primary px-4 py-1 text-white rounded-lg"
                        })
                    })
                ]
            })
        ]
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (AllNews);


/***/ }),

/***/ 940:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__),
/* harmony export */   "b": () => (/* binding */ getStaticProps)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5893);
/* harmony import */ var _components_Layout_Layout__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(8862);
/* harmony import */ var _pageComponents_AllNews_components_AllNews__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(4740);
/* harmony import */ var _utils_Metatag__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(1500);
/* harmony import */ var _utils_getNews__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(4174);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_components_Layout_Layout__WEBPACK_IMPORTED_MODULE_1__, _utils_getNews__WEBPACK_IMPORTED_MODULE_4__]);
([_components_Layout_Layout__WEBPACK_IMPORTED_MODULE_1__, _utils_getNews__WEBPACK_IMPORTED_MODULE_4__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);





const NewsMainPage = ({ totalPosts , totalPages , activePage  })=>{
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_components_Layout_Layout__WEBPACK_IMPORTED_MODULE_1__/* ["default"] */ .Z, {
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_utils_Metatag__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z, {
                heading: "Nepal Medical College",
                subheading: "Nepal Medical College",
                og_image: "https://nmc-api.terracecafe.com.np/upload/images/settings/test.jpeg.jpg",
                description: "Nepal Medical College",
                type: "article"
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pageComponents_AllNews_components_AllNews__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
                totalPages: totalPages && totalPages,
                totalPosts: totalPosts && totalPosts,
                activePage: activePage
            })
        ]
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (NewsMainPage);
async function getStaticProps() {
    try {
        const props = await (0,_utils_getNews__WEBPACK_IMPORTED_MODULE_4__/* .getNews */ .d)(1);
        return {
            props
        };
    } catch (e) {
        console.log(e);
        return {
            props: {
                data: null
            }
        };
    }
}

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 4174:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "d": () => (/* binding */ getNews)
/* harmony export */ });
/* harmony import */ var _axiosInstance_axiosInstance__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(2502);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_axiosInstance_axiosInstance__WEBPACK_IMPORTED_MODULE_0__]);
_axiosInstance_axiosInstance__WEBPACK_IMPORTED_MODULE_0__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];

const getNews = async (page)=>{
    try {
        const response = await _axiosInstance_axiosInstance__WEBPACK_IMPORTED_MODULE_0__/* ["default"].get */ .Z.get(`news/list`);
        const posts = response.data;
        const totalPosts = posts.slice(page === 1 ? 0 : (page - 1) * 10, page * 10);
        const totalPages = Math.ceil(posts.length / 10);
        return {
            totalPosts,
            totalPages
        };
    } catch (error) {
        console.error("Error fetching blog posts:", error);
        return {
            totalPosts: [],
            totalPages: 0
        };
    }
};

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ })

};
;