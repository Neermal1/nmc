"use strict";
exports.id = 7318;
exports.ids = [7318];
exports.modules = {

/***/ 7318:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5893);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(1853);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var antd__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(5725);
/* harmony import */ var antd__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(antd__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _axiosInstance_axiosInstance__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(2502);
/* harmony import */ var dayjs__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(1635);
/* harmony import */ var dayjs__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(dayjs__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var react_google_recaptcha__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(5623);
/* harmony import */ var react_google_recaptcha__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(react_google_recaptcha__WEBPACK_IMPORTED_MODULE_6__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_axiosInstance_axiosInstance__WEBPACK_IMPORTED_MODULE_4__]);
_axiosInstance_axiosInstance__WEBPACK_IMPORTED_MODULE_4__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];



//antd

//axiosInstance

//dayjs


const BookAppointmentForm = ({ departSlug , doctorSlug  })=>{
    //date format
    const today = dayjs__WEBPACK_IMPORTED_MODULE_5___default()(new Date()?.toISOString(), "YYYY-MM-DD");
    //antd props
    const { TextArea  } = antd__WEBPACK_IMPORTED_MODULE_3__.Input;
    const [form] = antd__WEBPACK_IMPORTED_MODULE_3__.Form.useForm();
    const { Option , OptGroup  } = antd__WEBPACK_IMPORTED_MODULE_3__.Select;
    //states
    const [patient_type, setPatientType] = (0,react__WEBPACK_IMPORTED_MODULE_2__.useState)("");
    const [gender_type, setGenderType] = (0,react__WEBPACK_IMPORTED_MODULE_2__.useState)("");
    const [departmentList, setDepartmentList] = (0,react__WEBPACK_IMPORTED_MODULE_2__.useState)([]);
    const [doctorList, setDoctorList] = (0,react__WEBPACK_IMPORTED_MODULE_2__.useState)([]);
    const [department_id, setDepartmentID] = (0,react__WEBPACK_IMPORTED_MODULE_2__.useState)("");
    const [doctorID, setdoctorID] = (0,react__WEBPACK_IMPORTED_MODULE_2__.useState)("");
    const [filtered_depart_id, setFilteredDepartId] = (0,react__WEBPACK_IMPORTED_MODULE_2__.useState)("");
    const [filtered_doctor_id, setFilteredDoctorId] = (0,react__WEBPACK_IMPORTED_MODULE_2__.useState)("");
    const [captchaValue, setCaptchaValue] = (0,react__WEBPACK_IMPORTED_MODULE_2__.useState)(null);
    const [appointDate, setAppointDate] = (0,react__WEBPACK_IMPORTED_MODULE_2__.useState)(today);
    const [birthDate, setBirthDate] = (0,react__WEBPACK_IMPORTED_MODULE_2__.useState)(today);
    const handleBirthDateChange = (dateString)=>{
        setBirthDate(dateString);
    };
    // const todayDate = dayjs(new Date()?.toISOString(), "YYYY-MM-DD");
    const handleAppointDateChange = (dateString)=>{
        setAppointDate(dateString);
    };
    const handle_patient_type = (e)=>{
        setPatientType(e?.target?.value);
    };
    const handle_gender_type = (e)=>{
        setGenderType(e?.target?.value);
    };
    //Here filtering the doctor and department to get their respective id and their name will be received from query
    const router = (0,next_router__WEBPACK_IMPORTED_MODULE_1__.useRouter)();
    // const { departSlug, doctorSlug } = router.query;
    (0,react__WEBPACK_IMPORTED_MODULE_2__.useEffect)(()=>{
        fetchDepartmentID_from_query();
    }, [
        departSlug,
        departmentList
    ]);
    const fetchDepartmentID_from_query = async ()=>{
        try {
            const department_filter = departmentList?.map((data, index)=>{
                return data?.departments?.filter((data)=>{
                    return data?.slug === departSlug;
                });
            });
            if (department_filter?.length > 0) {
                const filteredDepartId = department_filter?.[0]?.map((data)=>{
                    return data?.id;
                });
                setFilteredDepartId(filteredDepartId[0]);
            }
        } catch (e) {
            console.log(e);
        }
    };
    (0,react__WEBPACK_IMPORTED_MODULE_2__.useEffect)(()=>{
        fetchDoctorID_from_query();
    }, [
        filtered_depart_id
    ]);
    const fetchDoctorID_from_query = async ()=>{
        try {
            if (filtered_depart_id) {
                const response = await _axiosInstance_axiosInstance__WEBPACK_IMPORTED_MODULE_4__/* ["default"].get */ .Z.get(`departments/${filtered_depart_id}/doctors`);
                const doctor_filter = response.data?.filter?.((data, index)=>{
                    return data?.slug === doctorSlug;
                });
                if (doctor_filter) {
                    setFilteredDoctorId(doctor_filter?.[0]?.id);
                }
            }
        } catch (e) {
            console.log(e);
        }
    };
    //end of fetching here...
    const handleAppointment = async (values)=>{
        const payload = {
            first_name: values?.first_name,
            middle_name: values?.middle_name,
            last_name: values?.last_name,
            type: patient_type,
            gender: gender_type,
            dob: dayjs__WEBPACK_IMPORTED_MODULE_5___default()(birthDate).format("YYYY-MM-DD"),
            email: values?.email,
            address: values?.address,
            mobile: values?.phone_number,
            department_id: departSlug ? filtered_depart_id : department_id,
            doctor_id: doctorSlug ? filtered_doctor_id : doctorID,
            appointment_date: dayjs__WEBPACK_IMPORTED_MODULE_5___default()(appointDate).format("YYYY-MM-DD"),
            additional_information: values?.message
        };
        console.log(payload);
        try {
            if (captchaValue && payload) {
                const response = await _axiosInstance_axiosInstance__WEBPACK_IMPORTED_MODULE_4__/* ["default"].post */ .Z.post("appointment/add", payload);
                if (response?.status === 200) {
                    antd__WEBPACK_IMPORTED_MODULE_3__.notification.success({
                        message: response?.data?.message
                    });
                    form.resetFields();
                    recaptchaRef.current.reset();
                    setBirthDate("");
                    setAppointDate("");
                } else {
                    antd__WEBPACK_IMPORTED_MODULE_3__.notification.error({
                        message: "Sorry Something went wrong"
                    });
                    form.resetFields();
                    recaptchaRef.current.reset();
                }
            } else {
                antd__WEBPACK_IMPORTED_MODULE_3__.notification.error({
                    message: "Please verify you are a human or not"
                });
            }
        } catch (e) {
            console.log(e);
            antd__WEBPACK_IMPORTED_MODULE_3__.notification.error({
                message: "Sorry Something went wrong again"
            });
            form.resetFields();
            recaptchaRef.current.reset();
        }
    };
    (0,react__WEBPACK_IMPORTED_MODULE_2__.useEffect)(()=>{
        fetchDepartmentList();
    }, []);
    const fetchDepartmentList = async ()=>{
        try {
            const response = await _axiosInstance_axiosInstance__WEBPACK_IMPORTED_MODULE_4__/* ["default"].get */ .Z.get("departments/list");
            setDepartmentList(response?.data);
        } catch (e) {
            console.log(e);
        }
    };
    //here formatting the department list to include in select component form antd
    const formattedDepartment = departmentList?.map((department, index)=>({
            id: department?.id,
            label: department?.name,
            value: department?.name,
            children: department?.departments?.map((subcategory, index)=>({
                    label: subcategory?.name,
                    value: subcategory?.name,
                    id: subcategory?.id
                }))
        }));
    const handleDepartment = (value)=>{
        setDepartmentID(value);
    };
    (0,react__WEBPACK_IMPORTED_MODULE_2__.useEffect)(()=>{
        if (department_id !== "") {
            fetchDoctorList();
        }
    }, [
        department_id
    ]);
    const fetchDoctorList = async ()=>{
        try {
            const response = await _axiosInstance_axiosInstance__WEBPACK_IMPORTED_MODULE_4__/* ["default"].get */ .Z.get(`departments/${department_id}/doctors`);
            setDoctorList(response?.data);
        } catch (e) {
            console.log(e);
        }
    };
    //here formatting the doctor list to include in select component form antd
    const formattedDoctorList = doctorList?.map((doctor, index)=>({
            id: doctor?.id,
            label: doctor?.name,
            value: doctor?.name
        }));
    const handleDoctorChange = (value)=>{
        setdoctorID(value);
    };
    //recaptcha functions
    function onChangeCaptcha(value) {
        setCaptchaValue(value);
    }
    const recaptchaRef = (0,react__WEBPACK_IMPORTED_MODULE_2__.useRef)();
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
            className: "flex lg:flex-col gap-8 items-center justify-center ",
            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                className: "lg:w-[80%]  bg-[white] drop-shadow-md rounded-[8px] p-6 flex items-center justify-center",
                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(antd__WEBPACK_IMPORTED_MODULE_3__.Form, {
                    form: form,
                    onFinish: handleAppointment,
                    className: "flex flex-col gap-10 lg:w-[80%]",
                    children: [
                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                            children: [
                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                    className: "flex lg:flex-row flex-col gap-8",
                                    children: [
                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                            className: "w-[100%] form-gap",
                                            children: [
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                    className: "form-label",
                                                    children: "Department"
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(antd__WEBPACK_IMPORTED_MODULE_3__.Form.Item, {
                                                        name: "department",
                                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                            children: departSlug ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(antd__WEBPACK_IMPORTED_MODULE_3__.Select, {
                                                                value: departSlug && departSlug.replace(/-/g, " ").replace(/(^|\s)\S/g, function(t) {
                                                                    return t.toUpperCase();
                                                                }),
                                                                size: "large"
                                                            }) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(antd__WEBPACK_IMPORTED_MODULE_3__.Select, {
                                                                defaultValue: "Select a Department",
                                                                onChange: handleDepartment,
                                                                size: "large",
                                                                children: formattedDepartment?.map((department)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(OptGroup, {
                                                                        label: department?.label,
                                                                        children: department?.children?.map((subcategory, index)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(Option, {
                                                                                value: subcategory?.id,
                                                                                children: subcategory.label
                                                                            }, subcategory?.value))
                                                                    }, department?.value))
                                                            })
                                                        })
                                                    })
                                                })
                                            ]
                                        }),
                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                            className: "w-[100%] form-gap",
                                            children: [
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                    className: "form-label",
                                                    children: "Doctor"
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(antd__WEBPACK_IMPORTED_MODULE_3__.Form.Item, {
                                                        name: "doctor",
                                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                            children: doctorSlug ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(antd__WEBPACK_IMPORTED_MODULE_3__.Select, {
                                                                value: doctorSlug && doctorSlug.replace(/-/g, " ").replace(/(^|\s)\S/g, function(t) {
                                                                    return t.toUpperCase();
                                                                }),
                                                                size: "large"
                                                            }) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(antd__WEBPACK_IMPORTED_MODULE_3__.Select, {
                                                                defaultValue: "Select A Doctor",
                                                                onChange: handleDoctorChange,
                                                                size: "large",
                                                                children: formattedDoctorList?.map((doctor)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(Option, {
                                                                        label: doctor?.label,
                                                                        value: doctor?.id,
                                                                        children: doctor?.label
                                                                    }, doctor?.value))
                                                            })
                                                        })
                                                    })
                                                })
                                            ]
                                        })
                                    ]
                                }),
                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                    className: "form-gap",
                                    children: [
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                            className: "form-label",
                                            children: "Appointment Date"
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(antd__WEBPACK_IMPORTED_MODULE_3__.DatePicker, {
                                            className: "datepicker-style",
                                            format: "YYYY-MM-DD",
                                            size: "large",
                                            disabledDate: (current)=>current && current < dayjs__WEBPACK_IMPORTED_MODULE_5___default()().startOf("day"),
                                            value: appointDate,
                                            onChange: handleAppointDateChange
                                        })
                                    ]
                                })
                            ]
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                            className: "flex flex-col gap-6",
                            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                className: "flex flex-col gap-6",
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                        className: "",
                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(antd__WEBPACK_IMPORTED_MODULE_3__.Form.Item, {
                                            name: "patient",
                                            rules: [
                                                {
                                                    required: true,
                                                    message: "Please select an option!"
                                                }
                                            ],
                                            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(antd__WEBPACK_IMPORTED_MODULE_3__.Radio.Group, {
                                                onChange: handle_patient_type,
                                                children: [
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(antd__WEBPACK_IMPORTED_MODULE_3__.Radio, {
                                                        value: "New Patient",
                                                        children: "New Patient"
                                                    }),
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(antd__WEBPACK_IMPORTED_MODULE_3__.Radio, {
                                                        value: "Old Pateint",
                                                        children: "Old Patient"
                                                    })
                                                ]
                                            })
                                        })
                                    }),
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                        className: "grid lg:grid-cols-3 gap-4",
                                        children: [
                                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                className: "form-gap",
                                                children: [
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                        className: "",
                                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                            className: "form-label",
                                                            children: "First Name"
                                                        })
                                                    }),
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(antd__WEBPACK_IMPORTED_MODULE_3__.Form.Item, {
                                                        hasFeedback: true,
                                                        name: "first_name",
                                                        rules: [
                                                            {
                                                                required: true,
                                                                message: "Please provide your first name"
                                                            }
                                                        ],
                                                        className: "",
                                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(antd__WEBPACK_IMPORTED_MODULE_3__.Input, {
                                                            className: "lg:w-[100%] w-[300px]",
                                                            size: "large",
                                                            placeholder: "Enter your full name here"
                                                        })
                                                    })
                                                ]
                                            }),
                                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                className: "form-gap",
                                                children: [
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                        className: "",
                                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                            className: "form-label",
                                                            children: "Middle Name"
                                                        })
                                                    }),
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(antd__WEBPACK_IMPORTED_MODULE_3__.Form.Item, {
                                                        name: "middle_name",
                                                        className: "",
                                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(antd__WEBPACK_IMPORTED_MODULE_3__.Input, {
                                                            className: "lg:w-[100%] w-[300px]",
                                                            size: "large",
                                                            placeholder: "Enter your middle name here"
                                                        })
                                                    })
                                                ]
                                            }),
                                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                className: "form-gap",
                                                children: [
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                        className: "",
                                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                            className: "form-label",
                                                            children: "Last Name"
                                                        })
                                                    }),
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(antd__WEBPACK_IMPORTED_MODULE_3__.Form.Item, {
                                                        hasFeedback: true,
                                                        name: "last_name",
                                                        rules: [
                                                            {
                                                                required: true,
                                                                message: "Please provide your last name"
                                                            }
                                                        ],
                                                        className: "",
                                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(antd__WEBPACK_IMPORTED_MODULE_3__.Input, {
                                                            className: "lg:w-[100%] w-[300px]",
                                                            size: "large",
                                                            placeholder: "Enter your last name here"
                                                        })
                                                    })
                                                ]
                                            })
                                        ]
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                        className: "gender-type",
                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(antd__WEBPACK_IMPORTED_MODULE_3__.Form.Item, {
                                            name: "gender",
                                            rules: [
                                                {
                                                    required: true,
                                                    message: "Please select an option!"
                                                }
                                            ],
                                            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(antd__WEBPACK_IMPORTED_MODULE_3__.Radio.Group, {
                                                onChange: handle_gender_type,
                                                children: [
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(antd__WEBPACK_IMPORTED_MODULE_3__.Radio, {
                                                        value: "Male",
                                                        required: true,
                                                        children: "Male"
                                                    }),
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(antd__WEBPACK_IMPORTED_MODULE_3__.Radio, {
                                                        value: "Female",
                                                        required: true,
                                                        children: "Female"
                                                    }),
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(antd__WEBPACK_IMPORTED_MODULE_3__.Radio, {
                                                        value: "Others",
                                                        required: true,
                                                        children: "Others"
                                                    })
                                                ]
                                            })
                                        })
                                    }),
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                        className: "form-gap",
                                        children: [
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                className: "form-label",
                                                children: " Date of Birth"
                                            }),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(antd__WEBPACK_IMPORTED_MODULE_3__.DatePicker, {
                                                format: "YYYY-MM-DD",
                                                size: "large",
                                                value: birthDate,
                                                onChange: handleBirthDateChange
                                            })
                                        ]
                                    }),
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                        className: "grid  lg:grid-cols-3 gap-6",
                                        children: [
                                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                className: "form-gap",
                                                children: [
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                        className: "",
                                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                            className: "form-label",
                                                            children: "Address"
                                                        })
                                                    }),
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(antd__WEBPACK_IMPORTED_MODULE_3__.Form.Item, {
                                                        hasFeedback: true,
                                                        name: "address",
                                                        rules: [
                                                            {
                                                                required: true,
                                                                message: "Please provide your address"
                                                            }
                                                        ],
                                                        className: "",
                                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(antd__WEBPACK_IMPORTED_MODULE_3__.Input, {
                                                            className: "lg:w-[100%] w-[300px]",
                                                            size: "large",
                                                            placeholder: "Enter your full address"
                                                        })
                                                    })
                                                ]
                                            }),
                                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                className: "form-gap",
                                                children: [
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                        className: "",
                                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                            className: "form-label",
                                                            children: "Mobile Number"
                                                        })
                                                    }),
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(antd__WEBPACK_IMPORTED_MODULE_3__.Form.Item, {
                                                        hasFeedback: true,
                                                        name: "phone_number",
                                                        rules: [
                                                            {
                                                                required: true,
                                                                message: "Please provide your valid phone number"
                                                            },
                                                            {
                                                                pattern: /^[0-9]{10}$/,
                                                                message: "Mobile number must be 10 digits"
                                                            }
                                                        ],
                                                        className: "",
                                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(antd__WEBPACK_IMPORTED_MODULE_3__.Input, {
                                                            className: "lg:w-[100%] w-[300px]",
                                                            size: "large",
                                                            placeholder: "Enter your phone number here"
                                                        })
                                                    })
                                                ]
                                            }),
                                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                className: "form-gap",
                                                children: [
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                        className: "",
                                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                            className: "form-label",
                                                            children: "Email Address"
                                                        })
                                                    }),
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(antd__WEBPACK_IMPORTED_MODULE_3__.Form.Item, {
                                                        hasFeedback: true,
                                                        name: "email",
                                                        rules: [
                                                            {
                                                                required: true,
                                                                message: "Please provide your email address"
                                                            },
                                                            {
                                                                pattern: /^[a-z][a-z0-9._]*@[a-z][a-z0-9]*.[a-z]+/,
                                                                message: "Please provide your email address in correct format"
                                                            }
                                                        ],
                                                        className: "",
                                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(antd__WEBPACK_IMPORTED_MODULE_3__.Input, {
                                                            className: "lg:w-[100%] w-[300px]",
                                                            size: "large",
                                                            placeholder: "Enter your email address here"
                                                        })
                                                    })
                                                ]
                                            })
                                        ]
                                    }),
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                        className: "form-gap",
                                        children: [
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                className: "",
                                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                    className: "form-label",
                                                    children: "Are you suffering from Any Chronic Disease?"
                                                })
                                            }),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(antd__WEBPACK_IMPORTED_MODULE_3__.Form.Item, {
                                                hasFeedback: true,
                                                name: "message",
                                                rules: [
                                                    {
                                                        required: true,
                                                        message: "Please provide your disease name"
                                                    }
                                                ],
                                                className: "color-changer",
                                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(TextArea, {
                                                    rows: 4,
                                                    cols: 10,
                                                    className: "lg:w-[100%] w-[300px]",
                                                    placeholder: "Enter your disease name here",
                                                    autoSize: false
                                                })
                                            })
                                        ]
                                    }),
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                        className: "flex gap-4",
                                        children: [
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                                type: "checkbox"
                                            }),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                children: "I Agree to Terms and Conditions"
                                            })
                                        ]
                                    }),
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                        className: "flex flex-col gap-6",
                                        children: [
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((react_google_recaptcha__WEBPACK_IMPORTED_MODULE_6___default()), {
                                                ref: recaptchaRef,
                                                sitekey: "6Lf8xZ4pAAAAAKBGk_kfWHOs7XxmQX88U4-89bK4",
                                                onChange: onChangeCaptcha
                                            }),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(antd__WEBPACK_IMPORTED_MODULE_3__.Button, {
                                                className: "w-fit",
                                                htmlType: "submit",
                                                style: {
                                                    backgroundColor: "#1f2b6c",
                                                    color: "white"
                                                },
                                                size: "large",
                                                children: "Book Appointment"
                                            })
                                        ]
                                    })
                                ]
                            })
                        })
                    ]
                })
            })
        })
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (BookAppointmentForm);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ })

};
;