"use strict";
exports.id = 4521;
exports.ids = [4521];
exports.modules = {

/***/ 7320:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (/* binding */ Loader)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5893);

function Loader() {
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
        className: "h-screen flex items-center justify-center",
        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
            className: "loader"
        })
    });
}


/***/ }),

/***/ 1321:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (/* binding */ NoticeCard)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5893);
/* harmony import */ var _utils_FormatDate__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(2998);
/* harmony import */ var antd__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(5725);
/* harmony import */ var antd__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(antd__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(1853);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var react_icons_ai__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(9847);
/* harmony import */ var react_icons_ai__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(react_icons_ai__WEBPACK_IMPORTED_MODULE_4__);






function NoticeCard({ notice  }) {
    const [modalVisible, setModalVisible] = (0,react__WEBPACK_IMPORTED_MODULE_3__.useState)(false);
    const router = (0,next_router__WEBPACK_IMPORTED_MODULE_2__.useRouter)();
    const handleViewImage = ()=>{
        const isPDF = notice?.image_link?.endsWith(".pdf");
        if (isPDF) {
            window.open(`${notice?.image_link}`, "_blank");
        } else {
            // If the notice is an image, display it in the modal
            setModalVisible(true);
        }
    };
    const handleCloseModal = ()=>{
        setModalVisible(false);
    };
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                className: "border border-gray-500 rounded-2xl pl-4 py-4",
                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                    className: "flex items-center justify-between",
                    children: [
                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                            children: [
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                    className: "text-gray-700  font-medium text-base md:text-lg lg:text-xl",
                                    children: (0,_utils_FormatDate__WEBPACK_IMPORTED_MODULE_5__/* .formatDate */ .p)(notice?.created_at)
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h3", {
                                    className: "text-sm md:text-base lg:text-lg font-normal text-primary mb-2",
                                    children: notice?.title
                                })
                            ]
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("button", {
                                className: " bg-primary text-white px-4 py-2 text-base lg:text-lg font-bold rounded-s-xl",
                                onClick: handleViewImage,
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_icons_ai__WEBPACK_IMPORTED_MODULE_4__.AiFillEye, {
                                        className: "inline mr-1"
                                    }),
                                    "View"
                                ]
                            })
                        })
                    ]
                })
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(antd__WEBPACK_IMPORTED_MODULE_1__.Modal, {
                open: modalVisible,
                onCancel: handleCloseModal,
                footer: null,
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("img", {
                    src: notice?.image_link,
                    alt: notice?.title,
                    style: {
                        maxWidth: "100%",
                        height: "auto"
                    }
                })
            })
        ]
    });
}


/***/ }),

/***/ 9281:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (/* binding */ NoticeList)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5893);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(1853);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var react_paginate__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(9700);
/* harmony import */ var react_paginate__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react_paginate__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _hooks_useFetchData__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(7695);
/* harmony import */ var _NoticeCard__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(1321);
/* harmony import */ var _components_Loader_Loader__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(7320);
/* harmony import */ var _axiosInstance_axiosInstance__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(2502);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_hooks_useFetchData__WEBPACK_IMPORTED_MODULE_4__, _axiosInstance_axiosInstance__WEBPACK_IMPORTED_MODULE_7__]);
([_hooks_useFetchData__WEBPACK_IMPORTED_MODULE_4__, _axiosInstance_axiosInstance__WEBPACK_IMPORTED_MODULE_7__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);








function NoticeList() {
    const router = (0,next_router__WEBPACK_IMPORTED_MODULE_2__.useRouter)();
    const { fetchedData: categories , loading  } = (0,_hooks_useFetchData__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z)("notices/categories");
    const [selectedCategory, setSelectedCategory] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)("all");
    const [activePage, setActivePage] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(1);
    const noticesPerPage = 10;
    const [filteredNotices, setFilteredNotices] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)([]);
    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(()=>{
        const fetchNotices = async ()=>{
            try {
                const response = await _axiosInstance_axiosInstance__WEBPACK_IMPORTED_MODULE_7__/* ["default"].get */ .Z.get(`notice/category/${selectedCategory}`);
                setFilteredNotices(response.data);
            } catch (error) {
                console.error("Error fetching faculties:", error);
            }
        };
        fetchNotices();
    }, [
        selectedCategory
    ]);
    const totalNotices = filteredNotices?.length;
    const totalPages = Math.ceil(totalNotices / noticesPerPage);
    const handlePageChange = ({ selected  })=>{
        const nextPage = selected + 1;
        setActivePage(nextPage);
        router.push(`/notices/page/${nextPage}`);
    };
    const startIdx = (activePage - 1) * noticesPerPage;
    const endIdx = Math.min(startIdx + noticesPerPage, totalNotices);
    const noticesToShow = filteredNotices?.slice(startIdx, endIdx);
    if (loading) {
        return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_Loader_Loader__WEBPACK_IMPORTED_MODULE_6__/* ["default"] */ .Z, {});
    }
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("section", {
        className: "w-full h-full px-8 md:px-16 lg:px-24 xl:px-32 py-8",
        children: [
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: "flex flex-col lg:flex-row space-y-8 lg:space-y-0 lg:space-x-16",
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: "relative lg:w-1/4",
                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                            className: "flex space-x-4 lg:flex-col lg:space-x-0 border p-4 rounded-xl sticky top-32",
                            children: [
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                                    className: `mb-4 px-4 py-2 rounded-md focus:outline-none focus:border-none text-sm md:text-base font-medium ${selectedCategory === "all" ? "bg-primary text-white" : "bg-blue-50 text-black"}`,
                                    onClick: ()=>setSelectedCategory("all"),
                                    children: "All"
                                }),
                                categories?.map((category, index)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                                        className: `mb-4 px-4 py-2 rounded-md focus:outline-none focus:border-none text-sm md:text-base font-medium ${selectedCategory === category?.slug ? "bg-primary text-white" : "bg-blue-50 text-black"}`,
                                        onClick: ()=>setSelectedCategory(category?.slug),
                                        children: category?.name
                                    }, index))
                            ]
                        })
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: "w-full h-full flex flex-col gap-6",
                        children: noticesToShow?.map((notice, index)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_NoticeCard__WEBPACK_IMPORTED_MODULE_5__/* ["default"] */ .Z, {
                                notice: notice
                            }, index))
                    })
                ]
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                className: "m-8",
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((react_paginate__WEBPACK_IMPORTED_MODULE_3___default()), {
                    className: "pagination flex gap-2 items-center justify-end mt-12",
                    breakLabel: "...",
                    nextLabel: "Next \uD83E\uDC16",
                    onPageChange: handlePageChange,
                    pageRangeDisplayed: 5,
                    initialPage: activePage - 1,
                    pageCount: totalPages,
                    previousLabel: "\uD83E\uDC14 Previous",
                    renderOnZeroPageCount: null,
                    activeClassName: "bg-primary px-4 py-1 text-white rounded-lg"
                })
            })
        ]
    });
}

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 4521:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (/* binding */ Notices)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5893);
/* harmony import */ var _components_Banner_CommonBanner__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(7380);
/* harmony import */ var _components_Layout_Layout__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(8862);
/* harmony import */ var _pageComponents_notice_NoticeList__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(9281);
/* harmony import */ var _utils_Metatag__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(1500);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_components_Layout_Layout__WEBPACK_IMPORTED_MODULE_2__, _pageComponents_notice_NoticeList__WEBPACK_IMPORTED_MODULE_3__]);
([_components_Layout_Layout__WEBPACK_IMPORTED_MODULE_2__, _pageComponents_notice_NoticeList__WEBPACK_IMPORTED_MODULE_3__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);





function Notices() {
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_components_Layout_Layout__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_utils_Metatag__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z, {
                heading: "Nepal Medical College",
                subheading: "Notice",
                description: "Stay informed about important announcements, updates, and notices relevant to students, faculty, and staff. Explore the latest notices regarding academic schedules, events, administrative announcements, and more. At NMC, we strive to keep our community well-informed and engaged, ensuring a smooth and enriching educational experience for all.",
                og_image: "/images/ogImage/homePage.png"
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_Banner_CommonBanner__WEBPACK_IMPORTED_MODULE_1__/* ["default"] */ .Z, {
                headerName: "Notice",
                imageLink: "/images/Banners/notice.jpg"
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pageComponents_notice_NoticeList__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z, {})
        ]
    });
}

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 2998:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "p": () => (/* binding */ formatDate)
/* harmony export */ });
function formatDate(dateString) {
    const date = new Date(dateString);
    const day = date.getDate();
    const suffix = day === 1 ? "st" : day === 2 ? "nd" : day === 3 ? "rd" : "th";
    return `${day}${suffix} ${new Intl.DateTimeFormat("en-US", {
        month: "long"
    }).format(date)}, ${date.getFullYear()}`;
}


/***/ })

};
;