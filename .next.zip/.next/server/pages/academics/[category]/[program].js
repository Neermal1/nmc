"use strict";
(() => {
var exports = {};
exports.id = 4338;
exports.ids = [4338];
exports.modules = {

/***/ 4072:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* reexport safe */ private_next_pages_academics_category_program_tsx__WEBPACK_IMPORTED_MODULE_0__.Z),
/* harmony export */   "getServerSideProps": () => (/* reexport safe */ private_next_pages_academics_category_program_tsx__WEBPACK_IMPORTED_MODULE_0__.N)
/* harmony export */ });
/* harmony import */ var private_next_pages_academics_category_program_tsx__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(524);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([private_next_pages_academics_category_program_tsx__WEBPACK_IMPORTED_MODULE_0__]);
private_next_pages_academics_category_program_tsx__WEBPACK_IMPORTED_MODULE_0__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];

        // Next.js Route Loader
        
        
    
__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 4050:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "o": () => (/* binding */ SSR_fetchData)
/* harmony export */ });
/* harmony import */ var _axiosInstance_axiosInstance__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(2502);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_axiosInstance_axiosInstance__WEBPACK_IMPORTED_MODULE_0__]);
_axiosInstance_axiosInstance__WEBPACK_IMPORTED_MODULE_0__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];

const SSR_fetchData = async (url)=>{
    const response = await _axiosInstance_axiosInstance__WEBPACK_IMPORTED_MODULE_0__/* ["default"].get */ .Z.get(url);
    const data = response.data;
    return {
        data
    };
};

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 8507:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "Z": () => (/* binding */ ProgramDetails)
});

// EXTERNAL MODULE: ./node_modules/react/jsx-runtime.js
var jsx_runtime = __webpack_require__(5893);
// EXTERNAL MODULE: ./src/components/Banner/CommonBanner.tsx
var CommonBanner = __webpack_require__(7380);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(6689);
// EXTERNAL MODULE: external "react-icons/fa"
var fa_ = __webpack_require__(6290);
// EXTERNAL MODULE: ./node_modules/next/link.js
var next_link = __webpack_require__(1664);
var link_default = /*#__PURE__*/__webpack_require__.n(next_link);
;// CONCATENATED MODULE: ./src/pageComponents/academics/Professors.tsx


function Professors({ professors  }) {
    return /*#__PURE__*/ jsx_runtime.jsx("section", {
        children: /*#__PURE__*/ jsx_runtime.jsx("div", {
            className: "grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6",
            children: professors?.map((professor, index)=>/*#__PURE__*/ (0,jsx_runtime.jsxs)((link_default()), {
                    href: `/doctor/${professor?.slug}`,
                    className: "bg-white drop-shadow-md items-center rounded-[8px] p-6 flex flex-col gap-4",
                    children: [
                        /*#__PURE__*/ jsx_runtime.jsx("div", {
                            children: /*#__PURE__*/ jsx_runtime.jsx("img", {
                                src: professor && professor?.image_link,
                                alt: ""
                            })
                        }),
                        /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                            className: "black-color flex flex-col items-center gap-1",
                            children: [
                                /*#__PURE__*/ jsx_runtime.jsx("div", {
                                    className: "text-[18px]",
                                    children: professor?.title
                                }),
                                /*#__PURE__*/ jsx_runtime.jsx("div", {
                                    className: "text-[16px] text-center font-semibold",
                                    children: professor?.name
                                }),
                                professor?.designation !== null && /*#__PURE__*/ jsx_runtime.jsx("div", {
                                    className: "text-[16px] font-semibold",
                                    style: {
                                        color: "var(--accent-color)"
                                    },
                                    children: professor?.designation
                                }),
                                professor?.degree !== null && /*#__PURE__*/ jsx_runtime.jsx("div", {
                                    className: "text-[16px] font-semibold",
                                    style: {
                                        color: "var(--accent-color)"
                                    },
                                    children: professor?.degree
                                })
                            ]
                        })
                    ]
                }, index))
        })
    });
}

;// CONCATENATED MODULE: ./src/pageComponents/academics/ProgramDetails.tsx
/* eslint-disable react-hooks/exhaustive-deps */ 




function ProgramDetails({ data  }) {
    const [activeTab, setActiveTab] = (0,external_react_.useState)(0);
    const tabs = [
        {
            label: "Course Outline",
            icon: /*#__PURE__*/ jsx_runtime.jsx(fa_.FaBookOpen, {}),
            content: data?.course_outline
        },
        {
            label: "Admission",
            icon: /*#__PURE__*/ jsx_runtime.jsx(fa_.FaUserGraduate, {}),
            content: data?.admission
        },
        {
            label: "Career",
            icon: /*#__PURE__*/ jsx_runtime.jsx(fa_.FaBriefcase, {}),
            content: data?.career
        },
        {
            label: "Professors",
            icon: /*#__PURE__*/ jsx_runtime.jsx(fa_.FaBriefcase, {}),
            content: /*#__PURE__*/ jsx_runtime.jsx(Professors, {
                professors: data?.doctors
            })
        }
    ];
    return /*#__PURE__*/ (0,jsx_runtime.jsxs)(jsx_runtime.Fragment, {
        children: [
            /*#__PURE__*/ jsx_runtime.jsx(CommonBanner/* default */.Z, {
                headerName: "Academics",
                imageLink: "/images/Banners/academics-banner.jpg"
            }),
            /*#__PURE__*/ jsx_runtime.jsx("section", {
                className: "px-8 md:px-16 lg:px-24 xl:px-32 py-8 lg:py-24",
                children: /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                    children: [
                        /*#__PURE__*/ jsx_runtime.jsx("h1", {
                            className: "text-2xl lg:text-4xl text-primary pb-2",
                            children: data?.name
                        }),
                        /*#__PURE__*/ jsx_runtime.jsx("div", {
                            className: "w-32 border-2 border-primaryYellow"
                        }),
                        data?.image_link && /*#__PURE__*/ jsx_runtime.jsx("div", {
                            className: "my-4 lg:my-8",
                            children: /*#__PURE__*/ jsx_runtime.jsx("img", {
                                src: data?.image_link,
                                alt: "",
                                className: "w-full lg:h-96 object-center object-cover rounded-xl"
                            })
                        }),
                        /*#__PURE__*/ jsx_runtime.jsx("div", {
                            children: /*#__PURE__*/ jsx_runtime.jsx("p", {
                                className: "text-justify",
                                dangerouslySetInnerHTML: {
                                    __html: data?.description
                                }
                            })
                        }),
                        /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                            className: "mt-8",
                            children: [
                                /*#__PURE__*/ jsx_runtime.jsx("div", {
                                    className: "pb-4 flex items-center lg:justify-center lg:space-x-8 overflow-x-auto  no-scrollbar border-b border-gray-200",
                                    children: tabs.map((tab, index)=>/*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                                            className: `flex items-center px-4 lg:px-6 py-2 lg:py-4 rounded cursor-pointer text-nowrap ${activeTab === index ? "bg-secondary" : "hover:bg-blue-50"}`,
                                            onClick: ()=>setActiveTab(index),
                                            children: [
                                                /*#__PURE__*/ jsx_runtime.jsx("span", {
                                                    className: "mr-2 text-lg md:text-xl",
                                                    children: tab.icon
                                                }),
                                                /*#__PURE__*/ jsx_runtime.jsx("span", {
                                                    className: "text-lg md:text-xl",
                                                    children: tab.label
                                                })
                                            ]
                                        }, index))
                                }),
                                /*#__PURE__*/ jsx_runtime.jsx("div", {
                                    className: "mt-4",
                                    children: typeof tabs[activeTab].content === "string" ? /*#__PURE__*/ jsx_runtime.jsx("p", {
                                        className: "leading-[30px]",
                                        dangerouslySetInnerHTML: {
                                            __html: tabs[activeTab].content
                                        }
                                    }) : tabs[activeTab].content
                                })
                            ]
                        })
                    ]
                })
            })
        ]
    });
}


/***/ }),

/***/ 524:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "N": () => (/* binding */ getServerSideProps),
/* harmony export */   "Z": () => (/* binding */ ProgramDetail)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5893);
/* harmony import */ var _components_Layout_Layout__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(8862);
/* harmony import */ var _helperFunctions_fetchData_helper__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(4050);
/* harmony import */ var _pageComponents_academics_ProgramDetails__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(8507);
/* harmony import */ var _utils_Metatag__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(1500);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_components_Layout_Layout__WEBPACK_IMPORTED_MODULE_1__, _helperFunctions_fetchData_helper__WEBPACK_IMPORTED_MODULE_2__]);
([_components_Layout_Layout__WEBPACK_IMPORTED_MODULE_1__, _helperFunctions_fetchData_helper__WEBPACK_IMPORTED_MODULE_2__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);
/* eslint-disable react-hooks/exhaustive-deps */ 




function ProgramDetail({ data  }) {
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_components_Layout_Layout__WEBPACK_IMPORTED_MODULE_1__/* ["default"] */ .Z, {
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_utils_Metatag__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z, {
                heading: "Nepal Medical College",
                subheading: data?.meta_title || "Academics",
                description: data?.meta_description || "",
                og_image: data?.image_link
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pageComponents_academics_ProgramDetails__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z, {
                data: data
            })
        ]
    });
}
async function getServerSideProps({ params  }) {
    try {
        const { data  } = await (0,_helperFunctions_fetchData_helper__WEBPACK_IMPORTED_MODULE_2__/* .SSR_fetchData */ .o)(`academics/detail/${params?.program}`);
        return {
            props: {
                data
            }
        };
    } catch (e) {
        if (e.response && e.response.status === 429) {
            const retryAfter = parseInt(e.response.headers["retry-after"]);
            console.log("This is retry after", retryAfter);
            if (!isNaN(retryAfter)) {
                await new Promise((resolve)=>setTimeout(resolve, retryAfter * 1000));
                try {
                    console.log("refetching");
                    const { data  } = await (0,_helperFunctions_fetchData_helper__WEBPACK_IMPORTED_MODULE_2__/* .SSR_fetchData */ .o)(`academics/detail/${params?.slug}`);
                    return {
                        props: {
                            data
                        }
                    };
                } catch (retryError) {
                    console.error("Retry failed:", retryError);
                }
            }
            return {
                props: {
                    data: null
                }
            };
        } else {
            return {
                props: {
                    data: null
                }
            };
        }
    }
}

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 7066:
/***/ ((module) => {

module.exports = require("@ant-design/icons");

/***/ }),

/***/ 5725:
/***/ ((module) => {

module.exports = require("antd");

/***/ }),

/***/ 3280:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/app-router-context.js");

/***/ }),

/***/ 4964:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router-context.js");

/***/ }),

/***/ 1751:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/add-path-prefix.js");

/***/ }),

/***/ 3938:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/format-url.js");

/***/ }),

/***/ 1109:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/is-local-url.js");

/***/ }),

/***/ 8854:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/parse-path.js");

/***/ }),

/***/ 3297:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/remove-trailing-slash.js");

/***/ }),

/***/ 7782:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/resolve-href.js");

/***/ }),

/***/ 9232:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/utils.js");

/***/ }),

/***/ 968:
/***/ ((module) => {

module.exports = require("next/head");

/***/ }),

/***/ 6689:
/***/ ((module) => {

module.exports = require("react");

/***/ }),

/***/ 9847:
/***/ ((module) => {

module.exports = require("react-icons/ai");

/***/ }),

/***/ 567:
/***/ ((module) => {

module.exports = require("react-icons/bs");

/***/ }),

/***/ 6290:
/***/ ((module) => {

module.exports = require("react-icons/fa");

/***/ }),

/***/ 8514:
/***/ ((module) => {

module.exports = require("react-icons/fa6");

/***/ }),

/***/ 2750:
/***/ ((module) => {

module.exports = require("react-icons/fi");

/***/ }),

/***/ 150:
/***/ ((module) => {

module.exports = require("react-icons/pi");

/***/ }),

/***/ 9648:
/***/ ((module) => {

module.exports = import("axios");;

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [5893,1664,8862,1500,7380], () => (__webpack_exec__(4072)));
module.exports = __webpack_exports__;

})();