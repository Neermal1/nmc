"use strict";
(() => {
var exports = {};
exports.id = 1337;
exports.ids = [1337];
exports.modules = {

/***/ 9075:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* reexport safe */ private_next_pages_departments_department_name_index_tsx__WEBPACK_IMPORTED_MODULE_0__.Z),
/* harmony export */   "getServerSideProps": () => (/* reexport safe */ private_next_pages_departments_department_name_index_tsx__WEBPACK_IMPORTED_MODULE_0__.N)
/* harmony export */ });
/* harmony import */ var private_next_pages_departments_department_name_index_tsx__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(3901);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([private_next_pages_departments_department_name_index_tsx__WEBPACK_IMPORTED_MODULE_0__]);
private_next_pages_departments_department_name_index_tsx__WEBPACK_IMPORTED_MODULE_0__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];

        // Next.js Route Loader
        
        
    
__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 6439:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5893);

const SecondaryButton = ({ data  })=>{
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
        className: "group",
        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
            className: "bg-[#BFD2F8] transition-all duration-700 w-[100%] rounded-[8px] group-hover:bg-[#1F2B6C] px-6 py-4 lg:text-[22px] text-[16px] group-hover:text-[#FFDD1C] font-semibold flex items-center justify-center",
            children: data.name
        })
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (SecondaryButton);


/***/ }),

/***/ 4050:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "o": () => (/* binding */ SSR_fetchData)
/* harmony export */ });
/* harmony import */ var _axiosInstance_axiosInstance__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(2502);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_axiosInstance_axiosInstance__WEBPACK_IMPORTED_MODULE_0__]);
_axiosInstance_axiosInstance__WEBPACK_IMPORTED_MODULE_0__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];

const SSR_fetchData = async (url)=>{
    const response = await _axiosInstance_axiosInstance__WEBPACK_IMPORTED_MODULE_0__/* ["default"].get */ .Z.get(url);
    const data = response.data;
    return {
        data
    };
};

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 3951:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "Z": () => (/* binding */ components_DepartmentHeadDetail)
});

// EXTERNAL MODULE: ./node_modules/react/jsx-runtime.js
var jsx_runtime = __webpack_require__(5893);
// EXTERNAL MODULE: ./src/components/Banner/CommonBanner.tsx
var CommonBanner = __webpack_require__(7380);
// EXTERNAL MODULE: ./src/components/Button/SecondaryButton.tsx
var SecondaryButton = __webpack_require__(6439);
// EXTERNAL MODULE: ./node_modules/next/link.js
var next_link = __webpack_require__(1664);
var link_default = /*#__PURE__*/__webpack_require__.n(next_link);
// EXTERNAL MODULE: external "react-icons/lu"
var lu_ = __webpack_require__(8510);
;// CONCATENATED MODULE: ./src/pageComponents/DepartmentHead/components/DepartmentBranch.tsx



const DepartmentBranch = ({ branchData  })=>{
    return /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
        className: "flex flex-col gap-10",
        children: [
            branchData?.length > 0 && /*#__PURE__*/ jsx_runtime.jsx("div", {
                className: "text-[35px] font-semibold",
                children: "Explore our Department Branch"
            }),
            /*#__PURE__*/ jsx_runtime.jsx("div", {
                className: "grid lg:grid-cols-4 gap-8",
                children: branchData?.map((data, index)=>{
                    return /*#__PURE__*/ jsx_runtime.jsx((link_default()), {
                        href: `/departments/${data?.department_category?.slug}/${data?.slug}`,
                        className: "bg-white border-[1px] group  hover:drop-shadow-lg border-gray-300 px-6 py-3 rounded-[4px]",
                        children: /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                            className: "flex gap-4 items-center",
                            children: [
                                /*#__PURE__*/ jsx_runtime.jsx("div", {
                                    className: "bg-gray-200 group-hover:bg-gradient-to-r group-hover:transition-all group-hover:duration-1000 group-hover:from-[#4874e9] group-hover:to-[#3356dd]  h-[10vh] w-[10vh] rounded-[4px]  flex items-center justify-center",
                                    children: data?.image.length > 0 ? /*#__PURE__*/ jsx_runtime.jsx("img", {
                                        src: data?.image_link,
                                        alt: "loading",
                                        className: "h-[55px] w-[55px] object-cover"
                                    }) : /*#__PURE__*/ jsx_runtime.jsx("div", {
                                        className: "",
                                        children: /*#__PURE__*/ jsx_runtime.jsx(lu_.LuImageOff, {
                                            size: 36,
                                            className: "text-[#1e1e1e]"
                                        })
                                    })
                                }),
                                /*#__PURE__*/ jsx_runtime.jsx("div", {
                                    children: data?.name
                                })
                            ]
                        })
                    }, index);
                })
            })
        ]
    });
};
/* harmony default export */ const components_DepartmentBranch = (DepartmentBranch);

;// CONCATENATED MODULE: ./src/pageComponents/DepartmentHead/components/DepartmentHeadDetail.tsx






const DepartmentHeadDetail = ({ departmentHeadInfo  })=>{
    return /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
        className: "",
        children: [
            /*#__PURE__*/ jsx_runtime.jsx(CommonBanner/* default */.Z, {
                headerName: departmentHeadInfo?.details?.name,
                imageLink: departmentHeadInfo?.details?.image_link
            }),
            /*#__PURE__*/ jsx_runtime.jsx("div", {
                className: "layout component-padding ",
                children: /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                    className: "flex flex-col gap-20",
                    children: [
                        /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                            className: "grid lg:grid-cols-8 lg:gap-20 gap-10",
                            children: [
                                /*#__PURE__*/ jsx_runtime.jsx("div", {
                                    className: "lg:col-span-5",
                                    children: /*#__PURE__*/ jsx_runtime.jsx("div", {
                                        children: /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                                            className: "flex flex-col gap-10",
                                            children: [
                                                /*#__PURE__*/ jsx_runtime.jsx("div", {
                                                    className: "lg:text-[35px] text-[25px] font-semibold ",
                                                    children: departmentHeadInfo?.details?.name
                                                }),
                                                /*#__PURE__*/ jsx_runtime.jsx("div", {
                                                    className: " rounded-[8px] overflow-hidden",
                                                    children: /*#__PURE__*/ jsx_runtime.jsx("img", {
                                                        src: departmentHeadInfo?.details?.image_link,
                                                        alt: "",
                                                        className: "h-[50vh] w-[100%] object-cover rounded-[8px] hover:scale-110 transition-all duration-700"
                                                    })
                                                }),
                                                /*#__PURE__*/ jsx_runtime.jsx("div", {
                                                    className: "flex flex-col gap-6",
                                                    children: /*#__PURE__*/ jsx_runtime.jsx("div", {
                                                        className: "leading-[30px]",
                                                        dangerouslySetInnerHTML: {
                                                            __html: departmentHeadInfo?.details?.description
                                                        }
                                                    })
                                                })
                                            ]
                                        })
                                    })
                                }),
                                /*#__PURE__*/ jsx_runtime.jsx("div", {
                                    className: "lg:col-span-3 flex flex-col",
                                    children: /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                                        className: "border-[1px] flex flex-col gap-6  sticky top-[120px] bg-white hover:drop-shadow-md border-gray-300 rounded-[8px] p-6",
                                        children: [
                                            /*#__PURE__*/ jsx_runtime.jsx("div", {
                                                className: "border-b-[1px] border-gray-300",
                                                children: /*#__PURE__*/ jsx_runtime.jsx("div", {
                                                    className: " border-gray-300 mb-2 lg:text-[20px] font-medium",
                                                    children: "Related Departments"
                                                })
                                            }),
                                            /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                                                className: "flex flex-col gap-4",
                                                children: [
                                                    /*#__PURE__*/ jsx_runtime.jsx("div", {
                                                        className: "flex flex-col gap-2",
                                                        children: departmentHeadInfo?.others?.slice(0, 5).map((data, index)=>{
                                                            return /*#__PURE__*/ jsx_runtime.jsx("div", {
                                                                children: /*#__PURE__*/ (0,jsx_runtime.jsxs)((link_default()), {
                                                                    href: `/departments/${data?.slug}`,
                                                                    className: "flex items-center",
                                                                    children: [
                                                                        /*#__PURE__*/ jsx_runtime.jsx("div", {
                                                                            style: {
                                                                                color: "var(--accent-color)"
                                                                            },
                                                                            children: /*#__PURE__*/ jsx_runtime.jsx(lu_.LuDot, {
                                                                                size: 45
                                                                            })
                                                                        }),
                                                                        /*#__PURE__*/ jsx_runtime.jsx("div", {
                                                                            children: data?.name
                                                                        })
                                                                    ]
                                                                })
                                                            }, index);
                                                        })
                                                    }),
                                                    /*#__PURE__*/ jsx_runtime.jsx((link_default()), {
                                                        href: "/departments",
                                                        children: /*#__PURE__*/ jsx_runtime.jsx(SecondaryButton/* default */.Z, {
                                                            data: {
                                                                name: "View More"
                                                            }
                                                        })
                                                    })
                                                ]
                                            })
                                        ]
                                    })
                                })
                            ]
                        }),
                        /*#__PURE__*/ jsx_runtime.jsx("div", {
                            className: "flex flex-col gap-10",
                            children: /*#__PURE__*/ jsx_runtime.jsx(components_DepartmentBranch, {
                                branchData: departmentHeadInfo?.departments
                            })
                        }),
                        /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                            className: "flex flex-col gap-10",
                            children: [
                                departmentHeadInfo?.doctors.length > 0 && /*#__PURE__*/ jsx_runtime.jsx("div", {
                                    className: "text-[35px] font-semibold",
                                    children: "Meet Our Popular Doctors"
                                }),
                                /*#__PURE__*/ jsx_runtime.jsx("div", {
                                    className: "grid lg:grid-cols-4 md:grid-cols-3 gap-10 ",
                                    children: departmentHeadInfo?.doctors.length > 0 && departmentHeadInfo?.doctors?.map((data, index)=>{
                                        return /*#__PURE__*/ (0,jsx_runtime.jsxs)((link_default()), {
                                            href: `/doctor/${data?.slug}`,
                                            className: "bg-white drop-shadow-md items-center rounded-[8px] p-6 flex flex-col gap-4",
                                            children: [
                                                /*#__PURE__*/ jsx_runtime.jsx("div", {
                                                    children: /*#__PURE__*/ jsx_runtime.jsx("img", {
                                                        src: data && data?.image_link,
                                                        alt: ""
                                                    })
                                                }),
                                                /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                                                    className: "black-color flex flex-col items-center gap-1",
                                                    children: [
                                                        /*#__PURE__*/ jsx_runtime.jsx("div", {
                                                            className: "text-[18px]",
                                                            children: data?.title
                                                        }),
                                                        /*#__PURE__*/ jsx_runtime.jsx("div", {
                                                            className: "text-[16px] text-center font-semibold",
                                                            children: data?.name
                                                        }),
                                                        data?.designation !== null && /*#__PURE__*/ jsx_runtime.jsx("div", {
                                                            className: "text-[16px] font-semibold",
                                                            style: {
                                                                color: "var(--accent-color)"
                                                            },
                                                            children: data?.designation
                                                        }),
                                                        data?.degree !== null && /*#__PURE__*/ jsx_runtime.jsx("div", {
                                                            className: "text-[16px] font-semibold",
                                                            style: {
                                                                color: "var(--accent-color)"
                                                            },
                                                            children: data?.degree
                                                        })
                                                    ]
                                                })
                                            ]
                                        }, index);
                                    })
                                })
                            ]
                        })
                    ]
                })
            })
        ]
    });
};
/* harmony default export */ const components_DepartmentHeadDetail = (DepartmentHeadDetail);


/***/ }),

/***/ 3901:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "N": () => (/* binding */ getServerSideProps),
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5893);
/* harmony import */ var _components_Layout_Layout__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(8862);
/* harmony import */ var _pageComponents_DepartmentHead_components_DepartmentHeadDetail__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(3951);
/* harmony import */ var _utils_Metatag__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(1500);
/* harmony import */ var _helperFunctions_fetchData_helper__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(4050);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_components_Layout_Layout__WEBPACK_IMPORTED_MODULE_1__, _helperFunctions_fetchData_helper__WEBPACK_IMPORTED_MODULE_4__]);
([_components_Layout_Layout__WEBPACK_IMPORTED_MODULE_1__, _helperFunctions_fetchData_helper__WEBPACK_IMPORTED_MODULE_4__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);
//components




//api data

const DepartmentHead = ({ data  })=>{
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_components_Layout_Layout__WEBPACK_IMPORTED_MODULE_1__/* ["default"] */ .Z, {
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_utils_Metatag__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z, {
                heading: `${data?.details?.meta_title ? data?.details?.meta_title : "Nepal Medical College"}`,
                subheading: `${data?.details?.meta_description ? data?.details?.meta_description : "Hospital"}`,
                og_image: `${data?.details?.image_link}`,
                description: `${data?.details?.meta_description}`
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pageComponents_DepartmentHead_components_DepartmentHeadDetail__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
                departmentHeadInfo: data
            })
        ]
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (DepartmentHead);
async function getServerSideProps({ params  }) {
    try {
        const { data  } = await (0,_helperFunctions_fetchData_helper__WEBPACK_IMPORTED_MODULE_4__/* .SSR_fetchData */ .o)(`departments/${params?.department_name}/details`);
        return {
            props: {
                data
            }
        };
    } catch (e) {
        if (e.response && e.response.status === 429) {
            const retryAfter = parseInt(e.response.headers["retry-after"]);
            console.log("This is retry after", retryAfter);
            if (!isNaN(retryAfter)) {
                await new Promise((resolve)=>setTimeout(resolve, retryAfter * 1000));
                try {
                    console.log("refetching");
                    const { data  } = await (0,_helperFunctions_fetchData_helper__WEBPACK_IMPORTED_MODULE_4__/* .SSR_fetchData */ .o)(`departments/${params?.department_head}/details`);
                    return {
                        props: {
                            data
                        }
                    };
                } catch (retryError) {
                    console.error("Retry failed:", retryError);
                }
            }
            return {
                props: {
                    data: null
                }
            };
        } else {
            return {
                props: {
                    data: null
                }
            };
        }
    }
}

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 7066:
/***/ ((module) => {

module.exports = require("@ant-design/icons");

/***/ }),

/***/ 5725:
/***/ ((module) => {

module.exports = require("antd");

/***/ }),

/***/ 3280:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/app-router-context.js");

/***/ }),

/***/ 4964:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router-context.js");

/***/ }),

/***/ 1751:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/add-path-prefix.js");

/***/ }),

/***/ 3938:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/format-url.js");

/***/ }),

/***/ 1109:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/is-local-url.js");

/***/ }),

/***/ 8854:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/parse-path.js");

/***/ }),

/***/ 3297:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/remove-trailing-slash.js");

/***/ }),

/***/ 7782:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/resolve-href.js");

/***/ }),

/***/ 9232:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/utils.js");

/***/ }),

/***/ 968:
/***/ ((module) => {

module.exports = require("next/head");

/***/ }),

/***/ 6689:
/***/ ((module) => {

module.exports = require("react");

/***/ }),

/***/ 9847:
/***/ ((module) => {

module.exports = require("react-icons/ai");

/***/ }),

/***/ 567:
/***/ ((module) => {

module.exports = require("react-icons/bs");

/***/ }),

/***/ 6290:
/***/ ((module) => {

module.exports = require("react-icons/fa");

/***/ }),

/***/ 8514:
/***/ ((module) => {

module.exports = require("react-icons/fa6");

/***/ }),

/***/ 2750:
/***/ ((module) => {

module.exports = require("react-icons/fi");

/***/ }),

/***/ 8510:
/***/ ((module) => {

module.exports = require("react-icons/lu");

/***/ }),

/***/ 150:
/***/ ((module) => {

module.exports = require("react-icons/pi");

/***/ }),

/***/ 9648:
/***/ ((module) => {

module.exports = import("axios");;

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [5893,1664,8862,1500,7380], () => (__webpack_exec__(9075)));
module.exports = __webpack_exports__;

})();