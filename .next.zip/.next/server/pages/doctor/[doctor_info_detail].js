"use strict";
(() => {
var exports = {};
exports.id = 5373;
exports.ids = [5373];
exports.modules = {

/***/ 7962:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* reexport safe */ private_next_pages_doctor_doctor_info_detail_tsx__WEBPACK_IMPORTED_MODULE_0__.Z),
/* harmony export */   "getServerSideProps": () => (/* reexport safe */ private_next_pages_doctor_doctor_info_detail_tsx__WEBPACK_IMPORTED_MODULE_0__.N)
/* harmony export */ });
/* harmony import */ var private_next_pages_doctor_doctor_info_detail_tsx__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(1517);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([private_next_pages_doctor_doctor_info_detail_tsx__WEBPACK_IMPORTED_MODULE_0__]);
private_next_pages_doctor_doctor_info_detail_tsx__WEBPACK_IMPORTED_MODULE_0__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];

        // Next.js Route Loader
        
        
    
__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 7786:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5893);

const Button = ({ data  })=>{
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
        className: "bg-[#BFD2F8] w-fit px-6 py-2 rounded-full transition-all duration-700 hover:bg-[#1F2B6C] hover:text-[#FFDD1C] flex items-center justify-center",
        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
            children: data?.name
        })
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Button);


/***/ }),

/***/ 4050:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "o": () => (/* binding */ SSR_fetchData)
/* harmony export */ });
/* harmony import */ var _axiosInstance_axiosInstance__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(2502);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_axiosInstance_axiosInstance__WEBPACK_IMPORTED_MODULE_0__]);
_axiosInstance_axiosInstance__WEBPACK_IMPORTED_MODULE_0__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];

const SSR_fetchData = async (url)=>{
    const response = await _axiosInstance_axiosInstance__WEBPACK_IMPORTED_MODULE_0__/* ["default"].get */ .Z.get(url);
    const data = response.data;
    return {
        data
    };
};

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 9796:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "Z": () => (/* binding */ components_DoctorDetail)
});

// EXTERNAL MODULE: ./node_modules/react/jsx-runtime.js
var jsx_runtime = __webpack_require__(5893);
// EXTERNAL MODULE: ./node_modules/next/link.js
var next_link = __webpack_require__(1664);
var link_default = /*#__PURE__*/__webpack_require__.n(next_link);
// EXTERNAL MODULE: ./node_modules/next/image.js
var next_image = __webpack_require__(5675);
var image_default = /*#__PURE__*/__webpack_require__.n(next_image);
// EXTERNAL MODULE: ./src/components/Banner/CommonBanner.tsx
var CommonBanner = __webpack_require__(7380);
// EXTERNAL MODULE: ./src/components/Button/Button.tsx
var Button = __webpack_require__(7786);
;// CONCATENATED MODULE: ./public/images/random/suitcase.png
/* harmony default export */ const suitcase = ({"src":"/_next/static/media/suitcase.2cdd03eb.png","height":128,"width":128,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAICAYAAADED76LAAAA5klEQVR42mOAgTnBDPxzwrRqVsbpl0wLYBCAS6hJmdkzMDja5FibLKxwMjla5Wx6BMQGiYHlJFVi/itoZf4XUMv4z6CS+QuEBYFskBhIjkFKNem/jGbuH1W93L+Mcnn/mYAYxJbVyvsjDZRj0LEqeqRnU/mfQSbzX4h/wn8QZpDN/KdtXvxfx7LoEYN3zLpL4Rl7/8t7rvw1taPuDwiD2GHpu/97R6+7xOAVueZBZPbZ/9E5Z/8HpBwH4+jcs/+jgHyQHIO5c3Oig9+0SXY+k7tdA2f2uARM73UJXtDk6D9jgplTUxIA9aJpWsZUcHYAAAAASUVORK5CYII=","blurWidth":8,"blurHeight":8});
;// CONCATENATED MODULE: ./public/images/random/department.png
/* harmony default export */ const department = ({"src":"/_next/static/media/department.68fa0849.png","height":64,"width":64,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAICAYAAADED76LAAAAlUlEQVR42l2MsQrCQBBErwoWqVKl2q3dQyz8AUGuskglWAlKCuUWAoH8v2/hCjHwyLuZuUu/n2af1Hz6C+uZYpDsB8l1DZoP0SVkZnDk/6LYxHxTvGVzIrwiC9zgGSgOS3QxuKjVhwDlLghXiC6JeSEYOaia7wVAGY5QEmHHc3fNfmJYcMDJuNQxqD3Bh+INawMnM++/zN84wyTM2LkAAAAASUVORK5CYII=","blurWidth":8,"blurHeight":8});
;// CONCATENATED MODULE: ./src/pageComponents/DoctorDetail/components/DoctorMoreDetailCard.tsx

const DoctorMoreDetailCard = ({ children , title  })=>{
    return /*#__PURE__*/ jsx_runtime.jsx("div", {
        className: "group",
        children: /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
            className: "bg-white lg:h-fit h-[18vh]   group-hover:bg-gradient-to-r  from-[#4874e9] group-hover:text-white break-words group-hover:to-[#3356dd]  rounded-[8px] flex flex-col gap-4 drop-shadow-md p-6 ",
            children: [
                /*#__PURE__*/ jsx_runtime.jsx("div", {
                    className: "font-bold",
                    children: title
                }),
                /*#__PURE__*/ jsx_runtime.jsx("main", {
                    className: "",
                    children: children
                })
            ]
        })
    });
};
/* harmony default export */ const components_DoctorMoreDetailCard = (DoctorMoreDetailCard);

;// CONCATENATED MODULE: ./src/pageComponents/DoctorDetail/components/DoctorDetail.tsx



//components





const DoctorDetail = ({ doctorInfo  })=>{
    return /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
        className: "black-color",
        children: [
            /*#__PURE__*/ jsx_runtime.jsx(CommonBanner/* default */.Z, {
                headerName: "Doctor Detail",
                imageLink: "https://img.freepik.com/premium-photo/medicine-healthcare-concept-team-group-doctors-nurses-showing-thumbs-up_380164-90454.jpg?w=1380"
            }),
            /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                className: "layout component-padding flex flex-col gap-16",
                children: [
                    /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                        className: "grid lg:grid-cols-8 gap-10",
                        children: [
                            /*#__PURE__*/ jsx_runtime.jsx("div", {
                                className: "lg:col-span-5",
                                children: /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                                    className: "flex flex-col gap-6",
                                    children: [
                                        /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                                            className: "flex flex-col gap-2",
                                            children: [
                                                /*#__PURE__*/ jsx_runtime.jsx("div", {
                                                    className: "lg:text-[35px] text-[25px] font-semibold",
                                                    children: doctorInfo?.name
                                                }),
                                                /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                                                    className: "grid lg:grid-cols-3 md:grid-cols-2 grid-cols-1 gap-4",
                                                    children: [
                                                        doctorInfo?.department?.name !== null && /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                                                            className: "flex items-center gap-2",
                                                            children: [
                                                                /*#__PURE__*/ jsx_runtime.jsx("div", {
                                                                    className: "bg-white drop-shadow-md rounded-[8px] flex items-center justify-center",
                                                                    children: /*#__PURE__*/ jsx_runtime.jsx((image_default()), {
                                                                        src: department,
                                                                        alt: "suitcase",
                                                                        height: 25,
                                                                        width: 25
                                                                    })
                                                                }),
                                                                /*#__PURE__*/ jsx_runtime.jsx("div", {
                                                                    className: "lg:text-[20px] text-[16px] text-[#1f2b6c] font-semibold",
                                                                    children: doctorInfo?.department ? doctorInfo?.department?.name : doctorInfo?.department_category?.name
                                                                })
                                                            ]
                                                        }),
                                                        doctorInfo?.designation !== null && /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                                                            className: "flex items-center gap-2",
                                                            children: [
                                                                /*#__PURE__*/ jsx_runtime.jsx("div", {
                                                                    className: "bg-white drop-shadow-md rounded-[8px] flex items-center justify-center",
                                                                    children: /*#__PURE__*/ jsx_runtime.jsx((image_default()), {
                                                                        src: suitcase,
                                                                        alt: "suitcase",
                                                                        height: 25,
                                                                        width: 25
                                                                    })
                                                                }),
                                                                /*#__PURE__*/ jsx_runtime.jsx("div", {
                                                                    className: "lg:text-[20px] text-[16px] text-[#1f2b6c] font-semibold",
                                                                    children: doctorInfo?.designation
                                                                })
                                                            ]
                                                        })
                                                    ]
                                                })
                                            ]
                                        }),
                                        /*#__PURE__*/ jsx_runtime.jsx("div", {
                                            className: "leading-[30px] lg:w-[80%]",
                                            dangerouslySetInnerHTML: {
                                                __html: doctorInfo?.info
                                            }
                                        }),
                                        /*#__PURE__*/ jsx_runtime.jsx((link_default()), {
                                            href: `/appointment/${doctorInfo?.department?.slug}/${doctorInfo?.slug}`,
                                            className: "w-fit",
                                            children: /*#__PURE__*/ jsx_runtime.jsx(Button/* default */.Z, {
                                                data: {
                                                    name: "Book An Appointment"
                                                }
                                            })
                                        })
                                    ]
                                })
                            }),
                            /*#__PURE__*/ jsx_runtime.jsx("div", {
                                className: "lg:col-span-3",
                                children: /*#__PURE__*/ jsx_runtime.jsx("div", {
                                    className: "",
                                    children: /*#__PURE__*/ jsx_runtime.jsx("img", {
                                        src: doctorInfo?.image_link,
                                        alt: "",
                                        className: "lg:h-[64vh] h-[50vh] object-cover w-[100%] rounded-[8px]"
                                    })
                                })
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                        className: "flex flex-col gap-10",
                        children: [
                            /*#__PURE__*/ jsx_runtime.jsx("div", {
                                className: "lg:text-[35px] text-[25px] font-semibold",
                                children: "More Details"
                            }),
                            /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                                className: "lg:flex grid md:grid-cols-2 grid-cols-1 lg:items-center gap-4 lg:flex-row flex-col",
                                children: [
                                    doctorInfo?.degree !== null && /*#__PURE__*/ jsx_runtime.jsx(components_DoctorMoreDetailCard, {
                                        title: "Degree",
                                        children: /*#__PURE__*/ jsx_runtime.jsx("div", {
                                            children: doctorInfo?.degree
                                        })
                                    }),
                                    doctorInfo?.nmc_no !== null && /*#__PURE__*/ jsx_runtime.jsx(components_DoctorMoreDetailCard, {
                                        title: "NMC NO",
                                        children: /*#__PURE__*/ jsx_runtime.jsx("div", {
                                            children: doctorInfo?.nmc_no
                                        })
                                    }),
                                    doctorInfo?.phone !== null && doctorInfo?.phone_status === 1 && /*#__PURE__*/ jsx_runtime.jsx(components_DoctorMoreDetailCard, {
                                        title: "Phone Number",
                                        children: /*#__PURE__*/ jsx_runtime.jsx("a", {
                                            href: `tel:${doctorInfo?.phone}`,
                                            children: doctorInfo?.phone
                                        })
                                    }),
                                    doctorInfo?.email !== null && /*#__PURE__*/ jsx_runtime.jsx(components_DoctorMoreDetailCard, {
                                        title: "Email",
                                        children: /*#__PURE__*/ jsx_runtime.jsx("a", {
                                            href: `mailto:${doctorInfo?.email}`,
                                            children: doctorInfo?.email
                                        })
                                    })
                                ]
                            })
                        ]
                    })
                ]
            })
        ]
    });
};
/* harmony default export */ const components_DoctorDetail = (DoctorDetail);


/***/ }),

/***/ 1517:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "N": () => (/* binding */ getServerSideProps),
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5893);
/* harmony import */ var _components_Layout_Layout__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(8862);
/* harmony import */ var _pageComponents_DoctorDetail_components_DoctorDetail__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(9796);
/* harmony import */ var _helperFunctions_fetchData_helper__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(4050);
/* harmony import */ var _utils_Metatag__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(1500);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_components_Layout_Layout__WEBPACK_IMPORTED_MODULE_1__, _helperFunctions_fetchData_helper__WEBPACK_IMPORTED_MODULE_3__]);
([_components_Layout_Layout__WEBPACK_IMPORTED_MODULE_1__, _helperFunctions_fetchData_helper__WEBPACK_IMPORTED_MODULE_3__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);
//components




//metatag

const DoctorInfoDetail = ({ data  })=>{
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_components_Layout_Layout__WEBPACK_IMPORTED_MODULE_1__/* ["default"] */ .Z, {
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_utils_Metatag__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z, {
                heading: "Nepal Medical College",
                subheading: data?.name,
                og_image: data?.image_link
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pageComponents_DoctorDetail_components_DoctorDetail__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
                doctorInfo: data
            })
        ]
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (DoctorInfoDetail);
async function getServerSideProps({ params  }) {
    try {
        const { data  } = await (0,_helperFunctions_fetchData_helper__WEBPACK_IMPORTED_MODULE_3__/* .SSR_fetchData */ .o)(`doctor/detail/${params?.doctor_info_detail}`);
        return {
            props: {
                data
            }
        };
    } catch (e) {
        if (e.response && e.response.status === 429) {
            const retryAfter = parseInt(e.response.headers["retry-after"]);
            console.log("This is retry after", retryAfter);
            if (!isNaN(retryAfter)) {
                await new Promise((resolve)=>setTimeout(resolve, retryAfter * 1000));
                try {
                    console.log("refetching");
                    const { data  } = await (0,_helperFunctions_fetchData_helper__WEBPACK_IMPORTED_MODULE_3__/* .SSR_fetchData */ .o)(`doctor/detail/${params?.doctor_info_detail}`);
                    return {
                        props: {
                            data
                        }
                    };
                } catch (retryError) {
                    console.error("Retry failed:", retryError);
                }
            }
            return {
                props: {
                    data: null
                }
            };
        } else {
            return {
                props: {
                    data: null
                }
            };
        }
    }
}

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 7066:
/***/ ((module) => {

module.exports = require("@ant-design/icons");

/***/ }),

/***/ 5725:
/***/ ((module) => {

module.exports = require("antd");

/***/ }),

/***/ 3918:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/amp-context.js");

/***/ }),

/***/ 5732:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/amp-mode.js");

/***/ }),

/***/ 3280:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/app-router-context.js");

/***/ }),

/***/ 2796:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/head-manager-context.js");

/***/ }),

/***/ 4486:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/image-blur-svg.js");

/***/ }),

/***/ 744:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/image-config-context.js");

/***/ }),

/***/ 5843:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/image-config.js");

/***/ }),

/***/ 9552:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/image-loader");

/***/ }),

/***/ 4964:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router-context.js");

/***/ }),

/***/ 1751:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/add-path-prefix.js");

/***/ }),

/***/ 3938:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/format-url.js");

/***/ }),

/***/ 1109:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/is-local-url.js");

/***/ }),

/***/ 8854:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/parse-path.js");

/***/ }),

/***/ 3297:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/remove-trailing-slash.js");

/***/ }),

/***/ 7782:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/resolve-href.js");

/***/ }),

/***/ 2470:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/side-effect.js");

/***/ }),

/***/ 9232:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/utils.js");

/***/ }),

/***/ 618:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/utils/warn-once.js");

/***/ }),

/***/ 968:
/***/ ((module) => {

module.exports = require("next/head");

/***/ }),

/***/ 6689:
/***/ ((module) => {

module.exports = require("react");

/***/ }),

/***/ 9847:
/***/ ((module) => {

module.exports = require("react-icons/ai");

/***/ }),

/***/ 567:
/***/ ((module) => {

module.exports = require("react-icons/bs");

/***/ }),

/***/ 6290:
/***/ ((module) => {

module.exports = require("react-icons/fa");

/***/ }),

/***/ 8514:
/***/ ((module) => {

module.exports = require("react-icons/fa6");

/***/ }),

/***/ 2750:
/***/ ((module) => {

module.exports = require("react-icons/fi");

/***/ }),

/***/ 150:
/***/ ((module) => {

module.exports = require("react-icons/pi");

/***/ }),

/***/ 9648:
/***/ ((module) => {

module.exports = import("axios");;

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [5893,1664,2636,5675,8862,1500,7380], () => (__webpack_exec__(7962)));
module.exports = __webpack_exports__;

})();