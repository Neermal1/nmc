"use strict";
(() => {
var exports = {};
exports.id = 5405;
exports.ids = [5405];
exports.modules = {

/***/ 57:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({"src":"/_next/static/media/girl.58e99fa5.png","height":758,"width":600,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAYAAAAICAYAAADaxo44AAAAy0lEQVR42mMAAU8nW4+u3IiPSV7GuiB+pLMeEwMIeKgzTD09rfT/3JKobhB/bW0cKwMI5OTklBya3fZ/epZbLYj/fG0HE8OzV2+NX338+vjM6TP/jx878fnRq3cBDCDw4t2nFS/efvh/5+HTnw9fvP1/7Nyld1VtbaEMT1+/v3b38Yv/T99+/HvjyrV/a1Ys/7N833Flhqu37x+//ejl/4cPH//f2FX2v7Gm5tG5J+/FGGYvXuG0++jpt0Dzn0/p7/9eOGGBDwMDAwMAfZlsYO2nkeMAAAAASUVORK5CYII=","blurWidth":6,"blurHeight":8});

/***/ }),

/***/ 6163:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* reexport safe */ private_next_pages_index_tsx__WEBPACK_IMPORTED_MODULE_0__.Z),
/* harmony export */   "getServerSideProps": () => (/* reexport safe */ private_next_pages_index_tsx__WEBPACK_IMPORTED_MODULE_0__.N)
/* harmony export */ });
/* harmony import */ var private_next_pages_index_tsx__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(85);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([private_next_pages_index_tsx__WEBPACK_IMPORTED_MODULE_0__]);
private_next_pages_index_tsx__WEBPACK_IMPORTED_MODULE_0__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];

        // Next.js Route Loader
        
        
    
__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 6706:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5893);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var antd__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(5725);
/* harmony import */ var antd__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(antd__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _hooks_useFetchData__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(7695);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_hooks_useFetchData__WEBPACK_IMPORTED_MODULE_3__]);
_hooks_useFetchData__WEBPACK_IMPORTED_MODULE_3__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];



//hooks

const Advertisement = ()=>{
    const { fetchedData  } = (0,_hooks_useFetchData__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z)("notices/popup");
    const [advLength, setAdvLength] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)();
    const [isModalOpen, setIsModalOpen] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(true);
    const [img, setImage] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)("");
    const advertisementLength = fetchedData?.length;
    const reversedAdvertisementData = fetchedData ? [
        ...fetchedData
    ].reverse() : null;
    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(()=>{
        setAdvLength(advertisementLength);
    }, [
        advertisementLength
    ]);
    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(()=>{
        setImage(reversedAdvertisementData?.[advLength - 1]?.image_link);
        console.log(reversedAdvertisementData?.[advLength - 1]?.image_link);
    }, [
        advLength
    ]);
    const handleCancel = ()=>{
        if (advLength > 1) {
            setAdvLength(advLength - 1);
        } else {
            setIsModalOpen(false);
        }
    };
    // useEffect(() => {
    //   if (isModalOpen) {
    //     document.body.style.overflow = "hidden";
    //   } else {
    //     document.body.style.overflow = "auto";
    //   }
    //   return () => {
    //     document.body.style.overflow = "auto";
    //   };
    // }, [isModalOpen]);
    if (fetchedData?.length > 0) {
        return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
            className: "",
            children: fetchedData && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(antd__WEBPACK_IMPORTED_MODULE_2__.Modal, {
                open: isModalOpen,
                onCancel: handleCancel,
                footer: false,
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("img", {
                    src: img,
                    alt: ""
                })
            })
        });
    }
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Advertisement);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 7786:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5893);

const Button = ({ data  })=>{
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
        className: "bg-[#BFD2F8] w-fit px-6 py-2 rounded-full transition-all duration-700 hover:bg-[#1F2B6C] hover:text-[#FFDD1C] flex items-center justify-center",
        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
            children: data?.name
        })
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Button);


/***/ }),

/***/ 6439:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5893);

const SecondaryButton = ({ data  })=>{
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
        className: "group",
        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
            className: "bg-[#BFD2F8] transition-all duration-700 w-[100%] rounded-[8px] group-hover:bg-[#1F2B6C] px-6 py-4 lg:text-[22px] text-[16px] group-hover:text-[#FFDD1C] font-semibold flex items-center justify-center",
            children: data.name
        })
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (SecondaryButton);


/***/ }),

/***/ 5653:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5893);
/* harmony import */ var react_icons_fa__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6290);
/* harmony import */ var react_icons_fa__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react_icons_fa__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react_icons_gr__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(8547);
/* harmony import */ var react_icons_gr__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react_icons_gr__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var react_icons_io__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(4751);
/* harmony import */ var react_icons_io__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react_icons_io__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var react_icons_md__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(4041);
/* harmony import */ var react_icons_md__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(react_icons_md__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _hooks_useFetchData__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(7695);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_hooks_useFetchData__WEBPACK_IMPORTED_MODULE_5__]);
_hooks_useFetchData__WEBPACK_IMPORTED_MODULE_5__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];





//hooks

const CallToAction = ()=>{
    const { fetchedData , loading  } = (0,_hooks_useFetchData__WEBPACK_IMPORTED_MODULE_5__/* ["default"] */ .Z)("company-profile");
    if (loading) {
        return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
            children: "Loading"
        });
    } else if (fetchedData) {
        return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
            style: {
                backgroundImage: `url("./images/callToAction/callBanner.png")`,
                backgroundSize: "cover",
                backgroundPosition: "center center"
            },
            className: "relative w-full overflow-y-hidden lg:bg-no-repeat  bg-cover",
            children: [
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                    className: "absolute top-0 left-0 right-0 bottom-0 w-full    bg-[#101A55] opacity-70"
                }),
                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                    className: "layout component-padding relative flex flex-col gap-20",
                    children: [
                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                            className: "flex  flex-col items-center justify-center",
                            children: [
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                    className: "text-white",
                                    children: "Get in Touch"
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                    className: "lg:text-[36px]  text-[28px] font-bold",
                                    style: {
                                        color: "var(--accent-main-color)"
                                    },
                                    children: "Contact Us"
                                })
                            ]
                        }),
                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                            className: "grid lg:grid-cols-4 gap-5",
                            children: [
                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                    className: "bg-white hover:bg-[#EAF1FF] p-8 rounded-[8px] flex flex-col gap-4",
                                    children: [
                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                            children: [
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                    className: "",
                                                    style: {
                                                        color: "var(--primary-color)"
                                                    },
                                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_icons_fa__WEBPACK_IMPORTED_MODULE_1__.FaPhoneAlt, {
                                                        size: 30
                                                    })
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                    className: "text-[20px] font-semibold mt-4",
                                                    style: {
                                                        color: "var(--primary-color)"
                                                    },
                                                    children: "Emergency"
                                                })
                                            ]
                                        }),
                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                            className: "flex flex-col gap-1",
                                            children: [
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("a", {
                                                    href: `tel:${fetchedData?.company_phone}`,
                                                    children: fetchedData?.company_phone
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("a", {
                                                    href: `tel:${fetchedData?.company_phone2}`,
                                                    children: fetchedData?.company_phone2
                                                })
                                            ]
                                        })
                                    ]
                                }),
                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                    className: "bg-white hover:bg-[#EAF1FF] p-8 rounded-[8px] flex flex-col gap-4",
                                    children: [
                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                            children: [
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                    className: "",
                                                    style: {
                                                        color: "var(--primary-color)"
                                                    },
                                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_icons_gr__WEBPACK_IMPORTED_MODULE_2__.GrLocation, {
                                                        size: 30
                                                    })
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                    className: "text-[20px] font-semibold mt-4",
                                                    style: {
                                                        color: "var(--primary-color)"
                                                    },
                                                    children: "Location"
                                                })
                                            ]
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                            className: "flex flex-col gap-1",
                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                children: fetchedData?.company_address
                                            })
                                        })
                                    ]
                                }),
                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                    className: "bg-white hover:bg-[#EAF1FF] p-8 rounded-[8px] flex flex-col gap-4",
                                    children: [
                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                            children: [
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                    className: "",
                                                    style: {
                                                        color: "var(--primary-color)"
                                                    },
                                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_icons_md__WEBPACK_IMPORTED_MODULE_4__.MdEmail, {
                                                        size: 30
                                                    })
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                    className: "text-[20px] font-semibold mt-4",
                                                    style: {
                                                        color: "var(--primary-color)"
                                                    },
                                                    children: "Email"
                                                })
                                            ]
                                        }),
                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                            className: "flex flex-col gap-1",
                                            children: [
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("a", {
                                                    href: `mailto:${fetchedData?.company_email}`,
                                                    children: fetchedData?.company_email
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("a", {
                                                    href: `mailto:${fetchedData?.company_email2}`,
                                                    children: fetchedData?.company_email2
                                                })
                                            ]
                                        })
                                    ]
                                }),
                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                    className: "bg-white hover:bg-[#EAF1FF] p-8 rounded-[8px] flex flex-col gap-4",
                                    children: [
                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                            children: [
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                    className: "",
                                                    style: {
                                                        color: "var(--primary-color)"
                                                    },
                                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_icons_io__WEBPACK_IMPORTED_MODULE_3__.IoIosTimer, {
                                                        size: 30
                                                    })
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                    className: "text-[20px] font-semibold mt-4",
                                                    style: {
                                                        color: "var(--primary-color)"
                                                    },
                                                    children: "Working Hours"
                                                })
                                            ]
                                        }),
                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                            className: "flex flex-col gap-1",
                                            children: [
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                    children: fetchedData?.working_hour
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                    children: fetchedData?.working_hour2
                                                })
                                            ]
                                        })
                                    ]
                                })
                            ]
                        })
                    ]
                })
            ]
        });
    } else {
        return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
            children: "Error"
        });
    }
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (CallToAction);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 4050:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "o": () => (/* binding */ SSR_fetchData)
/* harmony export */ });
/* harmony import */ var _axiosInstance_axiosInstance__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(2502);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_axiosInstance_axiosInstance__WEBPACK_IMPORTED_MODULE_0__]);
_axiosInstance_axiosInstance__WEBPACK_IMPORTED_MODULE_0__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];

const SSR_fetchData = async (url)=>{
    const response = await _axiosInstance_axiosInstance__WEBPACK_IMPORTED_MODULE_0__/* ["default"].get */ .Z.get(url);
    const data = response.data;
    return {
        data
    };
};

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 7129:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5893);
/* harmony import */ var _components_Button_Button__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(7786);
/* harmony import */ var _hooks_useFetchData__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(7695);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(1664);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(next_link__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var react_icons_lu__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(8510);
/* harmony import */ var react_icons_lu__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(react_icons_lu__WEBPACK_IMPORTED_MODULE_4__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_hooks_useFetchData__WEBPACK_IMPORTED_MODULE_2__]);
_hooks_useFetchData__WEBPACK_IMPORTED_MODULE_2__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];
//button components


//hooks

//images

//react icons

const ClinicalService = ()=>{
    const { fetchedData , loading  } = (0,_hooks_useFetchData__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z)("home/departments/list");
    if (loading) {
        return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
            children: "Loading"
        });
    } else {
        return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                className: "layout component-padding black-color",
                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                    className: "grid lg:grid-cols-2  grid-cols-1 gap-10",
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                            className: "",
                            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                className: "flex flex-col gap-8 sticky top-[140px]",
                                children: [
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                        className: "flex flex-col gap-6",
                                        children: [
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                style: {
                                                    color: "var(--primary-color)"
                                                },
                                                className: "lg:text-[36px] text-[25px] lg:font-bold font-semibold",
                                                children: "EXPLORE OUR CENTRES OF CLINICAL EXCELLENCE"
                                            }),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                className: "lg:text-[20px] text-[16px] font-medium",
                                                children: "Learn about the world class health care we provide"
                                            })
                                        ]
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_3___default()), {
                                        href: "/departments",
                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_Button_Button__WEBPACK_IMPORTED_MODULE_1__/* ["default"] */ .Z, {
                                            data: {
                                                name: "Explore More"
                                            }
                                        })
                                    })
                                ]
                            })
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                            className: "",
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                className: "grid lg:grid-cols-2 grid-cols-1 gap-8",
                                children: fetchedData?.map((data, index)=>{
                                    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_3___default()), {
                                        href: `/departments/${data?.slug}`,
                                        className: "group",
                                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                            className: "flex items-center gap-2 h-[12vh] group-hover:bg-[#1F2B6C] border-[#1e1e1e] border-[1px] px-6 py-3 rounded-[8px] group-hover:text-[#FFDD1C]",
                                            children: [
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                    children: data?.icon.length > 0 ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("img", {
                                                        src: data?.icon_link,
                                                        alt: "loading",
                                                        className: "h-[55px] w-[55px] object-contain"
                                                    }) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_icons_lu__WEBPACK_IMPORTED_MODULE_4__.LuImageOff, {
                                                            size: 36,
                                                            className: "text-[#1e1e1e]"
                                                        })
                                                    })
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {}),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                    className: "text-[16px] font-medium",
                                                    children: data?.name
                                                })
                                            ]
                                        })
                                    }, index);
                                })
                            })
                        })
                    ]
                })
            })
        });
    }
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (ClinicalService);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 9690:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5893);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(1664);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(next_link__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react_icons_fa__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(6290);
/* harmony import */ var react_icons_fa__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react_icons_fa__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var react_icons_ri__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(8098);
/* harmony import */ var react_icons_ri__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react_icons_ri__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var react_icons_md__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(4041);
/* harmony import */ var react_icons_md__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(react_icons_md__WEBPACK_IMPORTED_MODULE_4__);


//react icons



const Facility = ()=>{
    const facilityList = [
        {
            icons: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_icons_fa__WEBPACK_IMPORTED_MODULE_2__.FaHospitalAlt, {
                size: 45
            }),
            name: "Book An Appointment",
            slug: "/book-an-appointment"
        },
        {
            icons: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_icons_ri__WEBPACK_IMPORTED_MODULE_3__.RiFirstAidKitFill, {
                size: 45
            }),
            name: "Contact Us",
            slug: "/contact-us"
        },
        {
            icons: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_icons_md__WEBPACK_IMPORTED_MODULE_4__.MdHealthAndSafety, {
                size: 45
            }),
            name: "Our Department",
            slug: "departments"
        },
        {
            icons: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_icons_fa__WEBPACK_IMPORTED_MODULE_2__.FaUniversity, {
                size: 45
            }),
            name: "Research",
            slug: "research"
        }
    ];
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
        className: "layout component-padding",
        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
            className: "grid lg:grid-cols-4 grid-cols-1 gap-6",
            children: facilityList?.map((data, index)=>{
                return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_1___default()), {
                    href: data?.slug,
                    className: " group  ",
                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: "flex bg-[#BFD2F8] group-hover:bg-[#1F2B6C] rounded-[8px]  p-6 justify-center items-center gap-6",
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                className: "text-[#249CDE] group-hover:text-[#FFDD1C]",
                                children: data?.icons
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                className: "text-[16px] font-medium group-hover:text-[#FFDD1C]",
                                children: data?.name
                            })
                        ]
                    })
                }, index);
            })
        })
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Facility);


/***/ }),

/***/ 9178:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5893);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(5675);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(next_image__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(1664);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_link__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _components_componentHeader_ComponentHeader__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(8830);
/* harmony import */ var _components_Button_SecondaryButton__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(6439);
/* harmony import */ var react_icons_fa6__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(8514);
/* harmony import */ var react_icons_fa6__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(react_icons_fa6__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var react_icons_lu__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(8510);
/* harmony import */ var react_icons_lu__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(react_icons_lu__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var _public_images_healthCarePackage_girl_png__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(57);
/* harmony import */ var _hooks_useFetchData__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(7695);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_hooks_useFetchData__WEBPACK_IMPORTED_MODULE_8__]);
_hooks_useFetchData__WEBPACK_IMPORTED_MODULE_8__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];



//components


//react icons


//images

//hooks

const HealthCarePackages = ()=>{
    const { fetchedData , loading  } = (0,_hooks_useFetchData__WEBPACK_IMPORTED_MODULE_8__/* ["default"] */ .Z)("packages");
    if (loading) {
        return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
            children: "Loading"
        });
    } else {
        return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
            className: "layout component-padding black-color",
            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: "flex flex-col gap-20",
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: "flex flex-col items-center justify-center text-center",
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_componentHeader_ComponentHeader__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z, {
                            data: {
                                small_title: "We Care about your Health",
                                main_title: "OUR HEALTH CARE PACKAGES"
                            }
                        })
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: "grid lg:grid-cols-6 gap-10",
                        children: [
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                className: "bg-[#BFD2F8] lg:col-span-2 rounded-[8px] px-6 py-6 flex flex-col gap-4",
                                children: [
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                        className: "flex items-center",
                                        style: {
                                            color: "var(--primary-color)"
                                        },
                                        children: [
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                className: "lg:text-[26px] font-medium",
                                                children: "SAVE MORE WITH GOODPLANS"
                                            }),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_icons_fa6__WEBPACK_IMPORTED_MODULE_5__.FaArrowRightLong, {
                                                    size: 30
                                                })
                                            })
                                        ]
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                        className: "text-[14px] font-medium",
                                        children: "Choose a plan and get our health packages. Then get checked up for you and your loved once."
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                        className: "",
                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_image__WEBPACK_IMPORTED_MODULE_1___default()), {
                                            src: _public_images_healthCarePackage_girl_png__WEBPACK_IMPORTED_MODULE_7__/* ["default"] */ .Z,
                                            alt: "loading",
                                            className: "h-[45vh] object-contain"
                                        })
                                    })
                                ]
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                className: "lg:col-span-4   grid lg:grid-cols-2 gap-10",
                                children: fetchedData?.map((data, index)=>{
                                    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                        className: "border-[1px]  border-[#1e1e1e]  rounded-[8px] px-6 py-4",
                                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                            className: "flex flex-col justify-between gap-10 h-[100%] ",
                                            children: [
                                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                    className: "flex flex-col gap-6 ",
                                                    children: [
                                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                            className: "flex items-center gap-2 ",
                                                            children: [
                                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                                    children: data?.image.length > 0 ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("img", {
                                                                        src: data?.image_link,
                                                                        alt: "loading",
                                                                        className: "h-[50px] w-[50px] object-contain"
                                                                    }) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_icons_lu__WEBPACK_IMPORTED_MODULE_6__.LuImageOff, {
                                                                            size: 36,
                                                                            className: "text-[#1e1e1e]"
                                                                        })
                                                                    })
                                                                }),
                                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                                    className: "lg:text-[32px] font-bold text-[28px]",
                                                                    children: data?.name
                                                                })
                                                            ]
                                                        }),
                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                            className: "text-[22px] text-[#A9A9AA]",
                                                            children: "What You Will Get"
                                                        }),
                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                            className: "flex flex-col gap-4",
                                                            children: data?.details?.map((data, index)=>{
                                                                return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                                    className: "flex items-center gap-2 ",
                                                                    children: [
                                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_icons_fa6__WEBPACK_IMPORTED_MODULE_5__.FaCircleCheck, {
                                                                                className: "text-[#35353F]",
                                                                                size: 20
                                                                            })
                                                                        }),
                                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                                            className: "text-[18px]",
                                                                            children: data?.service
                                                                        })
                                                                    ]
                                                                }, index);
                                                            })
                                                        }),
                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                            className: "border-dashed border-t-[2px] border-[#35353F]",
                                                            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                                style: {
                                                                    marginTop: "8px",
                                                                    color: "var(--primary-color)"
                                                                },
                                                                className: "lg:text-[32px] font-bold text-[25px]",
                                                                children: [
                                                                    "Rs. ",
                                                                    data?.price.toLocaleString(),
                                                                    " /-"
                                                                ]
                                                            })
                                                        })
                                                    ]
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_2___default()), {
                                                    href: "/contact-us",
                                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_Button_SecondaryButton__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z, {
                                                        data: {
                                                            name: "Book Now"
                                                        }
                                                    })
                                                })
                                            ]
                                        })
                                    }, index);
                                })
                            })
                        ]
                    })
                ]
            })
        });
    }
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (HealthCarePackages);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 1926:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (/* binding */ HeroSection)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5893);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var antd__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(5725);
/* harmony import */ var antd__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(antd__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _components_Loader_Loader__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(7320);
/* harmony import */ var _hooks_useFetchData__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(7695);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_hooks_useFetchData__WEBPACK_IMPORTED_MODULE_4__]);
_hooks_useFetchData__WEBPACK_IMPORTED_MODULE_4__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];
/* eslint-disable @next/next/no-img-element */ 




function HeroSection() {
    const { fetchedData , loading  } = (0,_hooks_useFetchData__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z)("slider/list");
    if (loading) {
        return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_Loader_Loader__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z, {});
    } else if (fetchedData) {
        return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
            className: "w-full h-full",
            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(antd__WEBPACK_IMPORTED_MODULE_2__.Carousel, {
                autoplay: true,
                children: fetchedData?.map((image)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("img", {
                            src: image?.image_link,
                            alt: `Image ${image.id}`,
                            className: "w-full lg:h-[80vh] object-cover"
                        })
                    }, image?.id))
            })
        });
    }
}

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 8314:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5893);
/* harmony import */ var _components_Button_Button__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(7786);
/* harmony import */ var _components_componentHeader_ComponentHeader__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(8830);
/* harmony import */ var _hooks_useFetchData__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(7695);
/* harmony import */ var _utils_FormatDate__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(2998);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(1664);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(next_link__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var react_icons_fa__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(6290);
/* harmony import */ var react_icons_fa__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(react_icons_fa__WEBPACK_IMPORTED_MODULE_5__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_hooks_useFetchData__WEBPACK_IMPORTED_MODULE_3__]);
_hooks_useFetchData__WEBPACK_IMPORTED_MODULE_3__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];
//components







//hooks
const News = ()=>{
    const { fetchedData , loading  } = (0,_hooks_useFetchData__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z)("news/list");
    if (loading) {
        return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
            children: "Loading"
        });
    } else if (fetchedData) {
        return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
            className: "bg-[#EAF1FF] mt-20",
            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: "layout component-padding flex flex-col gap-20",
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: "flex items-center justify-center ",
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                            className: "text-center",
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_componentHeader_ComponentHeader__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
                                data: {
                                    small_title: "Better Information Better Health",
                                    main_title: "NEWS"
                                }
                            })
                        })
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: "grid lg:grid-cols-2 max-w-5xl mx-auto gap-10",
                        children: fetchedData?.slice(0, 4).map((data, index)=>{
                            return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((next_link__WEBPACK_IMPORTED_MODULE_4___default()), {
                                href: `/news/${data?.slug}`,
                                className: "flex gap-4",
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                            className: "h-[150px] w-[150px]",
                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("img", {
                                                src: data?.image_link,
                                                alt: "",
                                                className: "h-[150px] w-[150px] object-cover rounded-[8px]"
                                            })
                                        })
                                    }),
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                        className: "flex flex-col gap-4",
                                        children: [
                                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                children: [
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                        className: "text-[18px] font-semibold text-[#249CDE]",
                                                        children: data?.title
                                                    }),
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                        children: (0,_utils_FormatDate__WEBPACK_IMPORTED_MODULE_6__/* .formatDate */ .p)(data?.created_at)
                                                    })
                                                ]
                                            }),
                                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                className: "flex gap-2 items-center",
                                                children: [
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_icons_fa__WEBPACK_IMPORTED_MODULE_5__.FaEye, {
                                                        className: "text-[#249CDE]"
                                                    }),
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                        children: data?.views
                                                    })
                                                ]
                                            })
                                        ]
                                    })
                                ]
                            }, index);
                        })
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_4___default()), {
                        href: "/news",
                        className: "flex items-center justify-center",
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_Button_Button__WEBPACK_IMPORTED_MODULE_1__/* ["default"] */ .Z, {
                            data: {
                                name: "View More"
                            }
                        })
                    })
                ]
            })
        });
    } else {
        return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
            children: "Error"
        });
    }
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (News);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 4238:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "Z": () => (/* binding */ components_OurAcademics)
});

// EXTERNAL MODULE: ./node_modules/react/jsx-runtime.js
var jsx_runtime = __webpack_require__(5893);
// EXTERNAL MODULE: ./node_modules/next/link.js
var next_link = __webpack_require__(1664);
var link_default = /*#__PURE__*/__webpack_require__.n(next_link);
// EXTERNAL MODULE: external "react-icons/fa"
var fa_ = __webpack_require__(6290);
// EXTERNAL MODULE: external "react-icons/ri"
var ri_ = __webpack_require__(8098);
// EXTERNAL MODULE: external "react-icons/ci"
var ci_ = __webpack_require__(8625);
// EXTERNAL MODULE: external "react-icons/bs"
var bs_ = __webpack_require__(567);
// EXTERNAL MODULE: ./src/components/componentHeader/ComponentHeader.tsx
var ComponentHeader = __webpack_require__(8830);
;// CONCATENATED MODULE: ./public/images/random/collegestudent.png
/* harmony default export */ const collegestudent = ({"src":"/_next/static/media/collegestudent.edbb9094.png","height":1984,"width":1864,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAICAYAAADED76LAAAA+UlEQVR42g3KPU7CUADA8f97fUgfCG0MDYaPMGGixAVjogdw4xSewUMweQIXNy/ABfyYScRJIglMtSFgqy1Fmz4ZfttP3A1vciGkkFIQxxsC36fZamJZFnpPGTG47BmlCljS2oVvOu1DPM+jZBcpaxvV6LSJfhKCZchvrtCVEsk25bR/xnG3hUwzQbQ1vPsZcWbvFLm9HzH5BFVtI4bXA/OVaqqFP9LcRds5Utn4wQfTxQzxPHo0rlfHn88ouzWSYI50GuTLKZPxCyqVGlXUOM0uB/sWb6s1J/UKgd3j6ugc5QRPBudCiMWY1Sak5vaIXh8o1fuE/tr8A69ZWyGkLrAxAAAAAElFTkSuQmCC","blurWidth":8,"blurHeight":8});
// EXTERNAL MODULE: ./node_modules/next/image.js
var next_image = __webpack_require__(5675);
var image_default = /*#__PURE__*/__webpack_require__.n(next_image);
// EXTERNAL MODULE: ./src/components/Button/Button.tsx
var Button = __webpack_require__(7786);
;// CONCATENATED MODULE: ./src/pageComponents/Home/components/OurAcademics.tsx






//components

//images



const OurAcademics = ()=>{
    const academicList = [
        {
            title: "Gallery",
            icon: /*#__PURE__*/ jsx_runtime.jsx(ri_.RiGalleryFill, {
                size: 70
            }),
            slug: "/gallery"
        },
        {
            title: "Department",
            icon: /*#__PURE__*/ jsx_runtime.jsx(fa_.FaHospitalAlt, {
                size: 70
            }),
            slug: "/departments"
        },
        {
            title: "Research",
            icon: /*#__PURE__*/ jsx_runtime.jsx(fa_.FaSearchengin, {
                size: 70
            }),
            slug: "/research"
        },
        {
            title: "Notice",
            icon: /*#__PURE__*/ jsx_runtime.jsx(fa_.FaNewspaper, {
                size: 70
            }),
            slug: "/notices"
        },
        {
            title: "Facilities ",
            icon: /*#__PURE__*/ jsx_runtime.jsx(ri_.RiFirstAidKitLine, {
                size: 70
            }),
            slug: "/facilities"
        },
        {
            title: "Life At NMC",
            icon: /*#__PURE__*/ jsx_runtime.jsx(ci_.CiStethoscope, {
                size: 70
            }),
            slug: "/about"
        }
    ];
    return /*#__PURE__*/ jsx_runtime.jsx("div", {
        className: "layout component-padding",
        children: /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
            className: "grid lg:grid-cols-12 lg:gap-20 gap-10",
            children: [
                /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                    className: "flex flex-col lg:col-span-7 gap-10",
                    children: [
                        /*#__PURE__*/ jsx_runtime.jsx(ComponentHeader/* default */.Z, {
                            data: {
                                main_title: "OUR ACADEMICS"
                            }
                        }),
                        /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                            className: "flex flex-col gap-10 ",
                            children: [
                                /*#__PURE__*/ jsx_runtime.jsx("div", {
                                    className: "grid lg:grid-cols-3 gap-6 ",
                                    children: academicList?.map((data, index)=>{
                                        return /*#__PURE__*/ jsx_runtime.jsx((link_default()), {
                                            href: data?.slug,
                                            className: "border-[1px] group hover:bg-[#1F2B6C] gap-6 p-4 rounded-[8px]  flex flex-col items-center justify-center border-[#1e1e1e]",
                                            children: /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                                                className: "flex  flex-col gap-4 items-center justify-center",
                                                children: [
                                                    /*#__PURE__*/ jsx_runtime.jsx("div", {
                                                        className: "text-[#1F2B6C] group-hover:text-[#FFDD1C]",
                                                        children: data?.icon
                                                    }),
                                                    /*#__PURE__*/ jsx_runtime.jsx("div", {
                                                        className: "text-center font-medium group-hover:text-[#FFDD1C]",
                                                        children: data?.title
                                                    })
                                                ]
                                            })
                                        }, index);
                                    })
                                }),
                                /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                                    className: "flex flex-col md:flex-row items-center justify-around gap-2 text-white bg-[#1F2B6C] py-4 rounded-[8px]",
                                    children: [
                                        /*#__PURE__*/ jsx_runtime.jsx("div", {
                                            children: "For International Students :"
                                        }),
                                        /*#__PURE__*/ jsx_runtime.jsx("div", {
                                            children: /*#__PURE__*/ (0,jsx_runtime.jsxs)("a", {
                                                href: "tel:01-4911008",
                                                className: "flex items-center gap-2",
                                                children: [
                                                    /*#__PURE__*/ jsx_runtime.jsx("span", {
                                                        children: /*#__PURE__*/ jsx_runtime.jsx(bs_.BsFillTelephoneFill, {})
                                                    }),
                                                    /*#__PURE__*/ jsx_runtime.jsx("span", {
                                                        style: {
                                                            color: "var(--accent-main-color)"
                                                        },
                                                        children: "01-4911008"
                                                    })
                                                ]
                                            })
                                        })
                                    ]
                                })
                            ]
                        })
                    ]
                }),
                /*#__PURE__*/ jsx_runtime.jsx("div", {
                    className: "flex lg:justify-end lg:col-span-5 ",
                    children: /*#__PURE__*/ jsx_runtime.jsx("div", {
                        className: "overflow-hidden rounded-[8px]",
                        children: /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                            className: "relative hover:scale-110 transition-all duration-700   hover:cursor-pointer",
                            children: [
                                /*#__PURE__*/ jsx_runtime.jsx("div", {
                                    className: "",
                                    children: /*#__PURE__*/ jsx_runtime.jsx((image_default()), {
                                        src: collegestudent,
                                        alt: "",
                                        className: "object-cover h-[100%]  "
                                    })
                                }),
                                /*#__PURE__*/ jsx_runtime.jsx("div", {
                                    className: "absolute flex items-center justify-center rounded-b-[8px] bottom-0 h-[350px] bg-gradient-to-t from-[#101A55]  w-full",
                                    children: /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                                        className: "flex flex-col gap-8",
                                        children: [
                                            /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                                                className: "lg:text-[46px] font-bold text-[white]",
                                                children: [
                                                    "OUR",
                                                    " ",
                                                    /*#__PURE__*/ jsx_runtime.jsx("span", {
                                                        style: {
                                                            color: "var(--accent-main-color)"
                                                        },
                                                        className: "font-bold",
                                                        children: "JOURNALS"
                                                    })
                                                ]
                                            }),
                                            /*#__PURE__*/ jsx_runtime.jsx("a", {
                                                href: "https://jnmcth.nmcth.edu/",
                                                className: "flex",
                                                target: "_blank",
                                                children: /*#__PURE__*/ jsx_runtime.jsx(Button/* default */.Z, {
                                                    data: {
                                                        name: "DOWNLOADS"
                                                    }
                                                })
                                            })
                                        ]
                                    })
                                })
                            ]
                        })
                    })
                })
            ]
        })
    });
};
/* harmony default export */ const components_OurAcademics = (OurAcademics);


/***/ }),

/***/ 6823:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5893);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(1664);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(next_link__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _components_Button_Button__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(7786);
/* harmony import */ var _components_componentHeader_ComponentHeader__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(8830);
/* harmony import */ var _hooks_useFetchData__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(7695);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_hooks_useFetchData__WEBPACK_IMPORTED_MODULE_4__]);
_hooks_useFetchData__WEBPACK_IMPORTED_MODULE_4__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];


//components


//hooks

const WhyChooseUs = ()=>{
    const { fetchedData , loading  } = (0,_hooks_useFetchData__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z)("why-choose-us");
    if (loading) {
        return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
            children: "Loading"
        });
    } else {
        return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
            className: "layout component-padding flex flex-col gap-14",
            children: [
                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                    className: "grid lg:grid-cols-2 grid-cols-1 gap-10",
                    children: [
                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                            className: "flex flex-col gap-10",
                            children: [
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_componentHeader_ComponentHeader__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z, {
                                        data: {
                                            main_title: "Why Choose Us"
                                        }
                                    })
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                    dangerouslySetInnerHTML: {
                                        __html: fetchedData?.section?.description
                                    }
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_1___default()), {
                                        href: "/about",
                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_Button_Button__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
                                            data: {
                                                name: "Learn More"
                                            }
                                        })
                                    })
                                })
                            ]
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                            className: "flex lg:justify-end",
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                className: "overflow-hidden rounded-[8px] h-[50vh]  ",
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("img", {
                                    src: fetchedData?.section?.image_link,
                                    alt: "",
                                    className: "h-[50vh] w-[100%] object-cover  hover:scale-110 transition-all duration-700"
                                })
                            })
                        })
                    ]
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: "grid lg:grid-cols-4 gap-6 grid-cols-2",
                        children: fetchedData?.list?.map((data, index)=>{
                            return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                className: "flex gap-2 items-center justify-center",
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("img", {
                                            src: data?.image_link,
                                            alt: "",
                                            className: "h-[80px] w-[80px] object-contain"
                                        })
                                    }),
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                        className: "flex flex-col gap-1",
                                        children: [
                                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                style: {
                                                    color: "var(--accent-main-color)"
                                                },
                                                className: "lg:text-[48px] font-semibold",
                                                children: [
                                                    data?.number,
                                                    "+"
                                                ]
                                            }),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                className: "text-[12px]",
                                                children: data?.title
                                            })
                                        ]
                                    })
                                ]
                            }, index);
                        })
                    })
                })
            ]
        });
    }
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (WhyChooseUs);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 4278:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5893);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _TextTestimonial__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(6037);
/* harmony import */ var _VideoTestimonial__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(6380);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_TextTestimonial__WEBPACK_IMPORTED_MODULE_2__, _VideoTestimonial__WEBPACK_IMPORTED_MODULE_3__]);
([_TextTestimonial__WEBPACK_IMPORTED_MODULE_2__, _VideoTestimonial__WEBPACK_IMPORTED_MODULE_3__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);




const Testimonials = ()=>{
    const [activeTab, setActiveTab] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)("comments");
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
        className: "component-padding layout",
        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
            children: [
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h2", {
                    className: "lg:text-[36px]  text-[28px] font-bold text-primary mb-4 text-center",
                    children: "Testimonials"
                }),
                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                    className: "flex items-center justify-center space-x-4 lg:space-x-8 mb-4",
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                            className: `px-4 py-2 text-lg lg:text-xl font-medium ${activeTab === "comments" ? " text-primary  border-b-2 border-primary" : " text-gray-700"}`,
                            onClick: ()=>setActiveTab("comments"),
                            children: "Text"
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                            className: `px-4 py-2 text-lg lg:text-xl font-medium ${activeTab === "videos" ? " text-primary  border-b-2 border-primary" : " text-gray-700"}`,
                            onClick: ()=>setActiveTab("videos"),
                            children: "Videos"
                        })
                    ]
                }),
                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                    className: "mt-4 lg:mt-8",
                    children: [
                        activeTab === "comments" && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_TextTestimonial__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {}),
                        activeTab === "videos" && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_VideoTestimonial__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z, {})
                    ]
                })
            ]
        })
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Testimonials);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 6037:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5893);
/* harmony import */ var _components_Loader_Loader__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(7320);
/* harmony import */ var _hooks_useFetchData__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(7695);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var react_multi_carousel__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(5804);
/* harmony import */ var react_multi_carousel__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(react_multi_carousel__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var react_multi_carousel_lib_styles_css__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(2694);
/* harmony import */ var react_multi_carousel_lib_styles_css__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(react_multi_carousel_lib_styles_css__WEBPACK_IMPORTED_MODULE_5__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_hooks_useFetchData__WEBPACK_IMPORTED_MODULE_2__]);
_hooks_useFetchData__WEBPACK_IMPORTED_MODULE_2__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];






const TextTestimonials = ()=>{
    const { fetchedData , loading  } = (0,_hooks_useFetchData__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z)("testimonial/list");
    const testimonials = fetchedData?.text;
    if (loading) {
        return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_Loader_Loader__WEBPACK_IMPORTED_MODULE_1__/* ["default"] */ .Z, {});
    } else if (fetchedData) {
        return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((react_multi_carousel__WEBPACK_IMPORTED_MODULE_4___default()), {
                arrows: true,
                autoPlay: true,
                showDots: false,
                responsive: {
                    desktop: {
                        breakpoint: {
                            max: 3000,
                            min: 1024
                        },
                        items: 3,
                        partialVisibilityGutter: 40
                    },
                    mobile: {
                        breakpoint: {
                            max: 464,
                            min: 0
                        },
                        items: 1,
                        partialVisibilityGutter: 30
                    },
                    tablet: {
                        breakpoint: {
                            max: 1024,
                            min: 464
                        },
                        items: 2,
                        partialVisibilityGutter: 30
                    }
                },
                slidesToSlide: 1,
                swipeable: true,
                children: testimonials?.map((testimonial, index)=>/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: "bg-white rounded-es-3xl rounded-lg rounded-se-3xl shadow-md p-6 lg:p-8 border border-primary mx-4",
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                className: "text-gray-800 mb-4",
                                children: testimonial?.message
                            }),
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                className: "flex items-center",
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("img", {
                                        src: testimonial?.image_link,
                                        alt: testimonial?.name,
                                        className: "w-12 h-12 rounded-full mr-4"
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                        className: " text-primary",
                                        children: testimonial?.name
                                    })
                                ]
                            })
                        ]
                    }, index))
            })
        });
    }
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (TextTestimonials);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 6380:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5893);
/* harmony import */ var _components_Loader_Loader__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(7320);
/* harmony import */ var _hooks_useFetchData__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(7695);
/* harmony import */ var antd__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(5725);
/* harmony import */ var antd__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(antd__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var react_icons_go__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(5856);
/* harmony import */ var react_icons_go__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(react_icons_go__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var react_multi_carousel__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(5804);
/* harmony import */ var react_multi_carousel__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(react_multi_carousel__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var react_multi_carousel_lib_styles_css__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(2694);
/* harmony import */ var react_multi_carousel_lib_styles_css__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(react_multi_carousel_lib_styles_css__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var react_player__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(8924);
/* harmony import */ var react_player__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(react_player__WEBPACK_IMPORTED_MODULE_8__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_hooks_useFetchData__WEBPACK_IMPORTED_MODULE_2__]);
_hooks_useFetchData__WEBPACK_IMPORTED_MODULE_2__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];









const VideoTestimonials = ()=>{
    const { fetchedData , loading  } = (0,_hooks_useFetchData__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z)("testimonial/list");
    const testimonials = fetchedData?.video;
    const [selectedVideo, setSelectedVideo] = (0,react__WEBPACK_IMPORTED_MODULE_4__.useState)(null);
    const openVideoModal = (iframe)=>{
        setSelectedVideo(iframe);
    };
    const autoThumbnail = (link)=>{
        const videoId = link.split("v=")[1];
        if (videoId) {
            return `https://img.youtube.com/vi/${videoId}/hqdefault.jpg`;
        }
        return "";
    };
    if (loading) {
        return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_Loader_Loader__WEBPACK_IMPORTED_MODULE_1__/* ["default"] */ .Z, {});
    } else if (fetchedData) {
        return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
            className: "py-8",
            children: [
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((react_multi_carousel__WEBPACK_IMPORTED_MODULE_6___default()), {
                    arrows: true,
                    autoPlay: true,
                    draggable: true,
                    infinite: true,
                    responsive: {
                        desktop: {
                            breakpoint: {
                                max: 3000,
                                min: 1024
                            },
                            items: 3,
                            partialVisibilityGutter: 40
                        },
                        mobile: {
                            breakpoint: {
                                max: 464,
                                min: 0
                            },
                            items: 1,
                            partialVisibilityGutter: 30
                        },
                        tablet: {
                            breakpoint: {
                                max: 1024,
                                min: 464
                            },
                            items: 2,
                            partialVisibilityGutter: 30
                        }
                    },
                    showDots: false,
                    sliderClass: "",
                    slidesToSlide: 1,
                    swipeable: true,
                    children: testimonials?.map((videoItem, index)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(VideoCard, {
                            videoItem: videoItem,
                            onClick: ()=>openVideoModal(videoItem?.link),
                            thumbnailUrl: autoThumbnail(videoItem?.link)
                        }, index))
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(antd__WEBPACK_IMPORTED_MODULE_3__.Modal, {
                    open: selectedVideo !== null,
                    footer: null,
                    onCancel: ()=>{
                        setSelectedVideo(null);
                    },
                    destroyOnClose: true,
                    centered: true,
                    className: "w-full",
                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: "",
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((react_player__WEBPACK_IMPORTED_MODULE_8___default()), {
                            url: selectedVideo || undefined,
                            playing: true,
                            loop: true,
                            controls: true,
                            width: "100%",
                            style: {
                                maxWidth: "100%",
                                height: "auto"
                            }
                        })
                    })
                })
            ]
        });
    }
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (VideoTestimonials);
const VideoCard = ({ videoItem , onClick , thumbnailUrl  })=>/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
        className: "relative lg:w-96 lg:h-auto overflow-hidden cursor-pointer rounded-lg mx-8",
        onClick: onClick,
        style: {
            marginRight: "15px"
        },
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("img", {
                src: thumbnailUrl,
                alt: videoItem?.name,
                className: "w-full h-full object-cover rounded-lg scale-150"
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                className: "absolute inset-0 p-4 bg-black bg-opacity-60 text-white",
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                    className: "text-lg font-semibold",
                    children: videoItem?.name
                })
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                className: "absolute inset-0 flex items-center justify-center",
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_icons_go__WEBPACK_IMPORTED_MODULE_5__.GoPlay, {
                    className: "h-16 w-16 text-white"
                })
            })
        ]
    });

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 85:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "N": () => (/* binding */ getServerSideProps),
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5893);
/* harmony import */ var _components_Layout_Layout__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(8862);
/* harmony import */ var _components_callToAction_CallToAction__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(5653);
/* harmony import */ var _pageComponents_Home_components_ClinicalService__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(7129);
/* harmony import */ var _pageComponents_Home_components_Facility__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(9690);
/* harmony import */ var _pageComponents_Home_components_HealthCarePackages__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(9178);
/* harmony import */ var _pageComponents_Home_components_HeroSection__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(1926);
/* harmony import */ var _pageComponents_Home_components_News__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(8314);
/* harmony import */ var _pageComponents_Home_components_OurAcademics__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(4238);
/* harmony import */ var _pageComponents_Home_components_WhyChooseUs__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(6823);
/* harmony import */ var _pageComponents_testimonials_Testimonials__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(4278);
/* harmony import */ var _utils_Metatag__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(1500);
/* harmony import */ var _helperFunctions_fetchData_helper__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(4050);
/* harmony import */ var _pageComponents_Home_components_MsgFromDirect__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(8896);
/* harmony import */ var _components_Advertisement_Advertisement__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(6706);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_components_Layout_Layout__WEBPACK_IMPORTED_MODULE_1__, _components_callToAction_CallToAction__WEBPACK_IMPORTED_MODULE_2__, _pageComponents_Home_components_ClinicalService__WEBPACK_IMPORTED_MODULE_3__, _pageComponents_Home_components_HealthCarePackages__WEBPACK_IMPORTED_MODULE_5__, _pageComponents_Home_components_HeroSection__WEBPACK_IMPORTED_MODULE_6__, _pageComponents_Home_components_News__WEBPACK_IMPORTED_MODULE_7__, _pageComponents_Home_components_WhyChooseUs__WEBPACK_IMPORTED_MODULE_9__, _pageComponents_testimonials_Testimonials__WEBPACK_IMPORTED_MODULE_10__, _helperFunctions_fetchData_helper__WEBPACK_IMPORTED_MODULE_12__, _pageComponents_Home_components_MsgFromDirect__WEBPACK_IMPORTED_MODULE_13__, _components_Advertisement_Advertisement__WEBPACK_IMPORTED_MODULE_14__]);
([_components_Layout_Layout__WEBPACK_IMPORTED_MODULE_1__, _components_callToAction_CallToAction__WEBPACK_IMPORTED_MODULE_2__, _pageComponents_Home_components_ClinicalService__WEBPACK_IMPORTED_MODULE_3__, _pageComponents_Home_components_HealthCarePackages__WEBPACK_IMPORTED_MODULE_5__, _pageComponents_Home_components_HeroSection__WEBPACK_IMPORTED_MODULE_6__, _pageComponents_Home_components_News__WEBPACK_IMPORTED_MODULE_7__, _pageComponents_Home_components_WhyChooseUs__WEBPACK_IMPORTED_MODULE_9__, _pageComponents_testimonials_Testimonials__WEBPACK_IMPORTED_MODULE_10__, _helperFunctions_fetchData_helper__WEBPACK_IMPORTED_MODULE_12__, _pageComponents_Home_components_MsgFromDirect__WEBPACK_IMPORTED_MODULE_13__, _components_Advertisement_Advertisement__WEBPACK_IMPORTED_MODULE_14__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);
//components











//metatag

//data fetcher



const index = ({ data  }, { notice  })=>{
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_components_Layout_Layout__WEBPACK_IMPORTED_MODULE_1__/* ["default"] */ .Z, {
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_utils_Metatag__WEBPACK_IMPORTED_MODULE_11__/* ["default"] */ .Z, {
                heading: `${data?.meta_title}`,
                subheading: "Home",
                og_image: `${data?.logo_link}`,
                description: `${data?.meta_description}`
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_Advertisement_Advertisement__WEBPACK_IMPORTED_MODULE_14__/* ["default"] */ .Z, {}),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pageComponents_Home_components_HeroSection__WEBPACK_IMPORTED_MODULE_6__/* ["default"] */ .Z, {}),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pageComponents_Home_components_Facility__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z, {}),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pageComponents_Home_components_ClinicalService__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z, {}),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pageComponents_Home_components_HealthCarePackages__WEBPACK_IMPORTED_MODULE_5__/* ["default"] */ .Z, {}),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pageComponents_Home_components_WhyChooseUs__WEBPACK_IMPORTED_MODULE_9__/* ["default"] */ .Z, {}),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                className: "px-8 md:px-16 lg:px-24 xl:px-32 py-8 md:py-16 bg-[#EAF1FF]",
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pageComponents_Home_components_MsgFromDirect__WEBPACK_IMPORTED_MODULE_13__/* ["default"] */ .Z, {})
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pageComponents_Home_components_OurAcademics__WEBPACK_IMPORTED_MODULE_8__/* ["default"] */ .Z, {}),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pageComponents_testimonials_Testimonials__WEBPACK_IMPORTED_MODULE_10__/* ["default"] */ .Z, {}),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_callToAction_CallToAction__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {}),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pageComponents_Home_components_News__WEBPACK_IMPORTED_MODULE_7__/* ["default"] */ .Z, {})
        ]
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (index);
async function getServerSideProps() {
    try {
        const { data  } = await (0,_helperFunctions_fetchData_helper__WEBPACK_IMPORTED_MODULE_12__/* .SSR_fetchData */ .o)("company-profile");
        return {
            props: {
                data
            }
        };
    } catch (e) {
        if (e.response && e.response.status === 429) {
            const retryAfter = parseInt(e.response.headers["retry-after"]);
            console.log("This is retry after", retryAfter);
            if (!isNaN(retryAfter)) {
                await new Promise((resolve)=>setTimeout(resolve, retryAfter * 1000));
                try {
                    console.log("refetching");
                    const { data  } = await (0,_helperFunctions_fetchData_helper__WEBPACK_IMPORTED_MODULE_12__/* .SSR_fetchData */ .o)(`company-profile`);
                    return {
                        props: {
                            data
                        }
                    };
                } catch (retryError) {
                    console.error("Retry failed:", retryError);
                }
            }
            return {
                props: {
                    data: null
                }
            };
        } else {
            return {
                props: {
                    data: null
                }
            };
        }
    }
}

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 2998:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "p": () => (/* binding */ formatDate)
/* harmony export */ });
function formatDate(dateString) {
    const date = new Date(dateString);
    const day = date.getDate();
    const suffix = day === 1 ? "st" : day === 2 ? "nd" : day === 3 ? "rd" : "th";
    return `${day}${suffix} ${new Intl.DateTimeFormat("en-US", {
        month: "long"
    }).format(date)}, ${date.getFullYear()}`;
}


/***/ }),

/***/ 7066:
/***/ ((module) => {

module.exports = require("@ant-design/icons");

/***/ }),

/***/ 5725:
/***/ ((module) => {

module.exports = require("antd");

/***/ }),

/***/ 3918:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/amp-context.js");

/***/ }),

/***/ 5732:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/amp-mode.js");

/***/ }),

/***/ 3280:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/app-router-context.js");

/***/ }),

/***/ 2796:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/head-manager-context.js");

/***/ }),

/***/ 4486:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/image-blur-svg.js");

/***/ }),

/***/ 744:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/image-config-context.js");

/***/ }),

/***/ 5843:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/image-config.js");

/***/ }),

/***/ 9552:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/image-loader");

/***/ }),

/***/ 4964:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router-context.js");

/***/ }),

/***/ 1751:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/add-path-prefix.js");

/***/ }),

/***/ 3938:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/format-url.js");

/***/ }),

/***/ 1109:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/is-local-url.js");

/***/ }),

/***/ 8854:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/parse-path.js");

/***/ }),

/***/ 3297:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/remove-trailing-slash.js");

/***/ }),

/***/ 7782:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/resolve-href.js");

/***/ }),

/***/ 2470:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/side-effect.js");

/***/ }),

/***/ 9232:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/utils.js");

/***/ }),

/***/ 618:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/utils/warn-once.js");

/***/ }),

/***/ 968:
/***/ ((module) => {

module.exports = require("next/head");

/***/ }),

/***/ 6689:
/***/ ((module) => {

module.exports = require("react");

/***/ }),

/***/ 9847:
/***/ ((module) => {

module.exports = require("react-icons/ai");

/***/ }),

/***/ 567:
/***/ ((module) => {

module.exports = require("react-icons/bs");

/***/ }),

/***/ 8625:
/***/ ((module) => {

module.exports = require("react-icons/ci");

/***/ }),

/***/ 6290:
/***/ ((module) => {

module.exports = require("react-icons/fa");

/***/ }),

/***/ 8514:
/***/ ((module) => {

module.exports = require("react-icons/fa6");

/***/ }),

/***/ 2750:
/***/ ((module) => {

module.exports = require("react-icons/fi");

/***/ }),

/***/ 5856:
/***/ ((module) => {

module.exports = require("react-icons/go");

/***/ }),

/***/ 8547:
/***/ ((module) => {

module.exports = require("react-icons/gr");

/***/ }),

/***/ 4751:
/***/ ((module) => {

module.exports = require("react-icons/io");

/***/ }),

/***/ 8510:
/***/ ((module) => {

module.exports = require("react-icons/lu");

/***/ }),

/***/ 4041:
/***/ ((module) => {

module.exports = require("react-icons/md");

/***/ }),

/***/ 150:
/***/ ((module) => {

module.exports = require("react-icons/pi");

/***/ }),

/***/ 8098:
/***/ ((module) => {

module.exports = require("react-icons/ri");

/***/ }),

/***/ 5804:
/***/ ((module) => {

module.exports = require("react-multi-carousel");

/***/ }),

/***/ 8924:
/***/ ((module) => {

module.exports = require("react-player");

/***/ }),

/***/ 9648:
/***/ ((module) => {

module.exports = import("axios");;

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [5893,1664,2636,5675,8862,1500,8896], () => (__webpack_exec__(6163)));
module.exports = __webpack_exports__;

})();